﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 11;
        let normal_calorie_image_progress_img_level = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 11;
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bgh-03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 174,
              month_startY: 356,
              month_sc_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              month_tc_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              month_en_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 141,
              day_startY: 356,
              day_sc_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              day_tc_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              day_en_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Asset_109.png',
              day_unit_tc: 'Asset_109.png',
              day_unit_en: 'Asset_109.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 112,
              y: 322,
              week_en: ["Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png"],
              week_tc: ["Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png"],
              week_sc: ["Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 257,
              font_array: ["Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png","Asset_41.png","Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 132,
              y: 243,
              image_array: ["Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png","Asset_66.png","Asset_67.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 264,
              // y: 9,
              // font_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 8,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'Asset_99.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'Asset_100.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'Asset_101.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'Asset_102.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'Asset_103.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'Asset_104.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'Asset_105.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'Asset_106.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'Asset_107.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'Asset_108.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 336,
                h: 384,
                center_x: 264,
                center_y: 9,
                pos_x: 264,
                pos_y: 9,
                angle: 8,
                src: 'Asset_99.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 15,
              image_array: ["Asset_82.png","Asset_83.png","Asset_84.png","Asset_85.png","Asset_86.png"],
              image_length: 5,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 71,
              // y: 9,
              // font_array: ["Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -8,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Asset_99.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Asset_100.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Asset_101.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Asset_102.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Asset_103.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Asset_104.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Asset_105.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Asset_106.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Asset_107.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Asset_108.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 336,
                h: 384,
                center_x: 71,
                center_y: 9,
                pos_x: 71,
                pos_y: 9,
                angle: -8,
                src: 'Asset_99.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 15,
              image_array: ["Asset_77.png","Asset_78.png","Asset_79.png","Asset_80.png","Asset_81.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 53,
              hour_startY: 89,
              hour_array: ["Asset_87.png","Asset_88.png","Asset_89.png","Asset_90.png","Asset_91.png","Asset_92.png","Asset_93.png","Asset_94.png","Asset_95.png","Asset_96.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Asset_98.png',
              hour_unit_tc: 'Asset_98.png',
              hour_unit_en: 'Asset_98.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Asset_87.png","Asset_88.png","Asset_89.png","Asset_90.png","Asset_91.png","Asset_92.png","Asset_93.png","Asset_94.png","Asset_95.png","Asset_96.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bgaod-03.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 112,
              y: 322,
              week_en: ["Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png"],
              week_tc: ["Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png"],
              week_sc: ["Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 53,
              hour_startY: 89,
              hour_array: ["Asset_87.png","Asset_88.png","Asset_89.png","Asset_90.png","Asset_91.png","Asset_92.png","Asset_93.png","Asset_94.png","Asset_95.png","Asset_96.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Asset_98.png',
              hour_unit_tc: 'Asset_98.png',
              hour_unit_en: 'Asset_98.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Asset_87.png","Asset_88.png","Asset_89.png","Asset_90.png","Asset_91.png","Asset_92.png","Asset_93.png","Asset_94.png","Asset_95.png","Asset_96.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();
              normal_calorie_rotate_string = normal_calorie_rotate_string.padStart(4, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  img_offset -= normal_calorie_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 264 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();
              normal_step_rotate_string = normal_step_rotate_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 71 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}