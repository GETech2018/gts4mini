﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'Pac-man_BG2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 55,
              y: 95,
              src: 'LOCK2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 159,
              src: 'bt2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 7,
              y: 159,
              src: 'al2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 215,
              font_array: ["NN_30.png","NN_31.png","NN_32.png","NN_33.png","NN_34.png","NN_35.png","NN_36.png","NN_37.png","NN_38.png","NN_39.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'NN_ PERC.png',
              unit_tc: 'NN_ PERC.png',
              unit_en: 'NN_ PERC.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 212,
              src: 'Batticon20.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 106,
              y: 207,
              image_array: ["Pac_Bat_01.png","Pac_Bat_02.png","Pac_Bat_03.png","Pac_Bat_04.png","Pac_Bat_05.png","Pac_Bat_06.png","Pac_Bat_07.png","Pac_Bat_08.png","Pac_Bat_09.png","Pac_Bat_10.png","Pac_Bat_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 320,
              font_array: ["NN_50.png","NN_51.png","NN_52.png","NN_53.png","NN_54.png","NN_55.png","NN_56.png","NN_57.png","NN_58.png","NN_59.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 281,
              y: 335,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 320,
              font_array: ["NN_20.png","NN_21.png","NN_22.png","NN_23.png","NN_24.png","NN_25.png","NN_26.png","NN_27.png","NN_28.png","NN_29.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bpm_r.png',
              unit_tc: 'bpm_r.png',
              unit_en: 'bpm_r.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 340,
              image_array: ["Zone_101.png","Zone_102.png","Zone_103.png","Zone_104.png","Zone_105.png","Zone_106.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 139,
              y: 320,
              font_array: ["NN_00.png","NN_01.png","NN_02.png","NN_03.png","NN_04.png","NN_05.png","NN_06.png","NN_07.png","NN_08.png","NN_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Nr_58.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 152,
              y: 335,
              src: 'km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 320,
              font_array: ["NN_10.png","NN_11.png","NN_12.png","NN_13.png","NN_14.png","NN_15.png","NN_16.png","NN_17.png","NN_18.png","NN_19.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 37,
              w: 210,
              h: 50,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFFE2E800,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 86,
              font_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'deg.png',
              unit_tc: 'deg.png',
              unit_en: 'deg.png',
              negative_image: 'NR 20_-.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 275,
              y: 70,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 221,
              year_startY: 15,
              year_sc_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              year_tc_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              year_en_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 177,
              month_startY: 15,
              month_sc_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              month_tc_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              month_en_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              month_zero: 1,
              month_space: -1,
              month_unit_sc: 'NR 20x30_PT01.png',
              month_unit_tc: 'NR 20x30_PT01.png',
              month_unit_en: 'NR 20x30_PT01.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 132,
              day_startY: 15,
              day_sc_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              day_tc_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              day_en_array: ["NR 20x30_00.png","NR 20x30_01.png","NR 20x30_02.png","NR 20x30_03.png","NR 20x30_04.png","NR 20x30_05.png","NR 20x30_06.png","NR 20x30_07.png","NR 20x30_08.png","NR 20x30_09.png"],
              day_zero: 1,
              day_space: -1,
              day_unit_sc: 'NR 20x30_PT02.png',
              day_unit_tc: 'NR 20x30_PT02.png',
              day_unit_en: 'NR 20x30_PT02.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 150,
              hour_array: ["Time_H_Font_M5_01.png","Time_H_Font_M5_02.png","Time_H_Font_M5_03.png","Time_H_Font_M5_04.png","Time_H_Font_M5_05.png","Time_H_Font_M5_06.png","Time_H_Font_M5_07.png","Time_H_Font_M5_08.png","Time_H_Font_M5_09.png","Time_H_Font_M5_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DUEPT_00.png',
              hour_unit_tc: 'DUEPT_00.png',
              hour_unit_en: 'DUEPT_00.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Time_H_Font_01.png","Time_H_Font_02.png","Time_H_Font_03.png","Time_H_Font_04.png","Time_H_Font_05.png","Time_H_Font_06.png","Time_H_Font_07.png","Time_H_Font_08.png","Time_H_Font_09.png","Time_H_Font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'DUEPT_00.png',
              minute_unit_tc: 'DUEPT_00.png',
              minute_unit_en: 'DUEPT_00.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 220,
              second_startY: 150,
              second_array: ["Time_H_Font_M3_01.png","Time_H_Font_M3_02.png","Time_H_Font_M3_03.png","Time_H_Font_M3_04.png","Time_H_Font_M3_05.png","Time_H_Font_M3_06.png","Time_H_Font_M3_07.png","Time_H_Font_M3_08.png","Time_H_Font_M3_09.png","Time_H_Font_M3_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'Pac-man_BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 215,
              font_array: ["NN_00.png","NN_01.png","NN_02.png","NN_03.png","NN_04.png","NN_05.png","NN_06.png","NN_07.png","NN_08.png","NN_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'NN_ PERC.png',
              unit_tc: 'NN_ PERC.png',
              unit_en: 'NN_ PERC.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 212,
              src: 'Batticon20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 150,
              hour_array: ["Time_H_Font_M5_01.png","Time_H_Font_M5_02.png","Time_H_Font_M5_03.png","Time_H_Font_M5_04.png","Time_H_Font_M5_05.png","Time_H_Font_M5_06.png","Time_H_Font_M5_07.png","Time_H_Font_M5_08.png","Time_H_Font_M5_09.png","Time_H_Font_M5_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DUEPT 36x50_00.png',
              hour_unit_tc: 'DUEPT 36x50_00.png',
              hour_unit_en: 'DUEPT 36x50_00.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Time_H_Font_01.png","Time_H_Font_02.png","Time_H_Font_03.png","Time_H_Font_04.png","Time_H_Font_05.png","Time_H_Font_06.png","Time_H_Font_07.png","Time_H_Font_08.png","Time_H_Font_09.png","Time_H_Font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'DUEPT 36x50_00.png',
              minute_unit_tc: 'DUEPT 36x50_00.png',
              minute_unit_en: 'DUEPT 36x50_00.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 220,
              second_startY: 150,
              second_array: ["Time_H_Font_M3_01.png","Time_H_Font_M3_02.png","Time_H_Font_M3_03.png","Time_H_Font_M3_04.png","Time_H_Font_M3_05.png","Time_H_Font_M3_06.png","Time_H_Font_M3_07.png","Time_H_Font_M3_08.png","Time_H_Font_M3_09.png","Time_H_Font_M3_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 144,
              w: 100,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 144,
              w: 110,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 145,
              w: 110,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 70,
              w: 69,
              h: 72,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 71,
              w: 90,
              h: 70,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 260,
              w: 70,
              h: 100,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 260,
              w: 70,
              h: 100,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 260,
              w: 70,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 260,
              w: 70,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}