﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 277,
              y: 54,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 22,
              font_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 22,
              src: '0082.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 75,
              y: 22,
              src: '0083.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 22,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 22,
              src: '0081.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 189,
              year_startY: 22,
              year_sc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              year_tc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              year_en_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 22,
              src: 'data_bat_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 149,
              month_startY: 22,
              month_sc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              month_tc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              month_en_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 22,
              src: 'data_bat_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 109,
              day_startY: 22,
              day_sc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              day_tc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              day_en_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 54,
              font_array: ["wea_r_66.png","wea_r_67.png","wea_r_68.png","wea_r_69.png","wea_r_70.png","wea_r_71.png","wea_r_72.png","wea_r_73.png","wea_r_74.png","wea_r_75.png"],
              padding: false,
              h_space: 2,
              negative_image: 'wea_r_minus.png',
              invalid_image: 'wea_r_vopros.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 54,
              font_array: ["wea_r_66.png","wea_r_67.png","wea_r_68.png","wea_r_69.png","wea_r_70.png","wea_r_71.png","wea_r_72.png","wea_r_73.png","wea_r_74.png","wea_r_75.png"],
              padding: false,
              h_space: 2,
              negative_image: 'wea_r_minus.png',
              invalid_image: 'wea_r_vopros.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 54,
              src: 'wea_r_slash.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -4,
              y: 54,
              font_array: ["wea_r_66.png","wea_r_67.png","wea_r_68.png","wea_r_69.png","wea_r_70.png","wea_r_71.png","wea_r_72.png","wea_r_73.png","wea_r_74.png","wea_r_75.png"],
              padding: false,
              h_space: 2,
              negative_image: 'wea_r_minus.png',
              invalid_image: 'wea_r_vopros.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 54,
              image_array: ["weatrher_logo_0.png","weatrher_logo_1.png","weatrher_logo_2.png","weatrher_logo_3.png","weatrher_logo_4.png","weatrher_logo_5.png","weatrher_logo_6.png","weatrher_logo_7.png","weatrher_logo_8.png","weatrher_logo_9.png","weatrher_logo_10.png","weatrher_logo_11.png","weatrher_logo_12.png","weatrher_logo_13.png","weatrher_logo_14.png","weatrher_logo_15.png","weatrher_logo_16.png","weatrher_logo_17.png","weatrher_logo_18.png","weatrher_logo_19.png","weatrher_logo_20.png","weatrher_logo_21.png","weatrher_logo_22.png","weatrher_logo_23.png","weatrher_logo_24.png","weatrher_logo_25.png","weatrher_logo_26.png","weatrher_logo_27.png","weatrher_logo_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 328,
              font_array: ["dist_heart_0.png","dist_heart_1.png","dist_heart_2.png","dist_heart_3.png","dist_heart_4.png","dist_heart_5.png","dist_heart_6.png","dist_heart_7.png","dist_heart_8.png","dist_heart_9.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 331,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 328,
              font_array: ["dist_heart_0.png","dist_heart_1.png","dist_heart_2.png","dist_heart_3.png","dist_heart_4.png","dist_heart_5.png","dist_heart_6.png","dist_heart_7.png","dist_heart_8.png","dist_heart_9.png"],
              padding: true,
              h_space: 3,
              dot_image: 'dist_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 329,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 3,
              hour_startY: 108,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 183,
              minute_startY: 108,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 109,
              src: 'time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 99,
              font_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 131,
              y: 100,
              image_array: ["bat_aod_ico_0.png","bat_aod_ico_1.png","bat_aod_ico_2.png","bat_aod_ico_3.png","bat_aod_ico_4.png","bat_aod_ico_5.png","bat_aod_ico_6.png","bat_aod_ico_7.png","bat_aod_ico_8.png","bat_aod_ico_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 133,
              week_en: ["day_aod_1.png","day_aod_2.png","day_aod_3.png","day_aod_4.png","day_aod_5.png","day_aod_6.png","day_aod_7.png"],
              week_tc: ["day_aod_1.png","day_aod_2.png","day_aod_3.png","day_aod_4.png","day_aod_5.png","day_aod_6.png","day_aod_7.png"],
              week_sc: ["day_aod_1.png","day_aod_2.png","day_aod_3.png","day_aod_4.png","day_aod_5.png","day_aod_6.png","day_aod_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 157,
              month_startY: 135,
              month_sc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              month_tc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              month_en_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 135,
              src: 'data_bat_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 114,
              day_startY: 135,
              day_sc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              day_tc_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              day_en_array: ["data_bat_0.png","data_bat_1.png","data_bat_2.png","data_bat_3.png","data_bat_4.png","data_bat_5.png","data_bat_6.png","data_bat_7.png","data_bat_8.png","data_bat_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 238,
              font_array: ["wea_r_aod_66.png","wea_r_aod_67.png","wea_r_aod_68.png","wea_r_aod_69.png","wea_r_aod_70.png","wea_r_aod_71.png","wea_r_aod_72.png","wea_r_aod_73.png","wea_r_aod_74.png","wea_r_aod_75.png"],
              padding: false,
              h_space: 3,
              negative_image: 'wea_r_aod_minus.png',
              invalid_image: 'wea_r_aod_vopros.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 235,
              image_array: ["weatrher_logo_0.png","weatrher_logo_1.png","weatrher_logo_2.png","weatrher_logo_3.png","weatrher_logo_4.png","weatrher_logo_5.png","weatrher_logo_6.png","weatrher_logo_7.png","weatrher_logo_8.png","weatrher_logo_9.png","weatrher_logo_10.png","weatrher_logo_11.png","weatrher_logo_12.png","weatrher_logo_13.png","weatrher_logo_14.png","weatrher_logo_15.png","weatrher_logo_16.png","weatrher_logo_17.png","weatrher_logo_18.png","weatrher_logo_19.png","weatrher_logo_20.png","weatrher_logo_21.png","weatrher_logo_22.png","weatrher_logo_23.png","weatrher_logo_24.png","weatrher_logo_25.png","weatrher_logo_26.png","weatrher_logo_27.png","weatrher_logo_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 129,
              y: 65,
              src: '0083.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 65,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 65,
              src: '0081.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 108,
              hour_startY: 175,
              hour_array: ["time_aod_0.png","time_aod_1.png","time_aod_2.png","time_aod_3.png","time_aod_4.png","time_aod_5.png","time_aod_6.png","time_aod_7.png","time_aod_8.png","time_aod_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 175,
              minute_array: ["time_aod_0.png","time_aod_1.png","time_aod_2.png","time_aod_3.png","time_aod_4.png","time_aod_5.png","time_aod_6.png","time_aod_7.png","time_aod_8.png","time_aod_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 175,
              src: 'time_aod_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 326,
              w: 165,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 326,
              w: 138,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 115,
              w: 150,
              h: 200,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 115,
              w: 150,
              h: 200,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 276,
              y: 54,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 54,
              w: 51,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}