﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 30,
              month_sc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              month_tc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              month_en_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 30,
              day_sc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_tc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_en_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'D_sep.png',
              day_unit_tc: 'D_sep.png',
              day_unit_en: 'D_sep.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 139,
              y: 324,
              week_en: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              week_tc: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              week_sc: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 283,
              // center_y: 258,
              // start_angle: 27,
              // end_angle: 333,
              // radius: 35,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFF9B9995,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 283,
              center_y: 258,
              start_angle: 27,
              end_angle: 333,
              radius: 33,
              line_width: 4,
              corner_flag: 0,
              color: 0xFF9B9995,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 252,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 124,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 124,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 53,
              // center_y: 258,
              // start_angle: 27,
              // end_angle: 333,
              // radius: 35,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFF9B9995,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 53,
              center_y: 258,
              start_angle: 27,
              end_angle: 333,
              radius: 33,
              line_width: 4,
              corner_flag: 0,
              color: 0xFF9B9995,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 252,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 95,
              hour_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 100,
              minute_startY: 198,
              minute_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 30,
              month_sc_array: ["D_gray__0.png","D_gray__1.png","D_gray__2.png","D_gray__3.png","D_gray__4.png","D_gray__5.png","D_gray__6.png","D_gray__7.png","D_gray__8.png","D_gray__9.png"],
              month_tc_array: ["D_gray__0.png","D_gray__1.png","D_gray__2.png","D_gray__3.png","D_gray__4.png","D_gray__5.png","D_gray__6.png","D_gray__7.png","D_gray__8.png","D_gray__9.png"],
              month_en_array: ["D_gray__0.png","D_gray__1.png","D_gray__2.png","D_gray__3.png","D_gray__4.png","D_gray__5.png","D_gray__6.png","D_gray__7.png","D_gray__8.png","D_gray__9.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 30,
              day_sc_array: ["D_gray__0.png","D_gray__1.png","D_gray__2.png","D_gray__3.png","D_gray__4.png","D_gray__5.png","D_gray__6.png","D_gray__7.png","D_gray__8.png","D_gray__9.png"],
              day_tc_array: ["D_gray__0.png","D_gray__1.png","D_gray__2.png","D_gray__3.png","D_gray__4.png","D_gray__5.png","D_gray__6.png","D_gray__7.png","D_gray__8.png","D_gray__9.png"],
              day_en_array: ["D_gray__0.png","D_gray__1.png","D_gray__2.png","D_gray__3.png","D_gray__4.png","D_gray__5.png","D_gray__6.png","D_gray__7.png","D_gray__8.png","D_gray__9.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'D_gray__sep.png',
              day_unit_tc: 'D_gray__sep.png',
              day_unit_en: 'D_gray__sep.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 139,
              y: 324,
              week_en: ["ru_white_01_mon.png","ru_white_02_tue.png","ru_white_03_wed.png","ru_white_04_Thu.png","ru_white_05_fri.png","ru_white_06_sat.png","ru_white_07_sun.png"],
              week_tc: ["ru_white_01_mon.png","ru_white_02_tue.png","ru_white_03_wed.png","ru_white_04_Thu.png","ru_white_05_fri.png","ru_white_06_sat.png","ru_white_07_sun.png"],
              week_sc: ["ru_white_01_mon.png","ru_white_02_tue.png","ru_white_03_wed.png","ru_white_04_Thu.png","ru_white_05_fri.png","ru_white_06_sat.png","ru_white_07_sun.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 95,
              hour_array: ["T_white_0.png","T_white_1.png","T_white_2.png","T_white_3.png","T_white_4.png","T_white_5.png","T_white_6.png","T_white_7.png","T_white_8.png","T_white_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 100,
              minute_startY: 198,
              minute_array: ["T_white_0.png","T_white_1.png","T_white_2.png","T_white_3.png","T_white_4.png","T_white_5.png","T_white_6.png","T_white_7.png","T_white_8.png","T_white_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 84,
              w: 138,
              h: 218,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 238,
              y: 84,
              w: 90,
              h: 90,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 84,
              w: 90,
              h: 90,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 212,
              w: 90,
              h: 90,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 283,
                      center_y: 258,
                      start_angle: 27,
                      end_angle: 333,
                      radius: 33,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFF9B9995,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 53,
                      center_y: 258,
                      start_angle: 27,
                      end_angle: 333,
                      radius: 33,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFF9B9995,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}