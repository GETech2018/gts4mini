﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 336,
              // h: 384,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg01.png', path: 'bg01.png' },
                { id: 2, preview: 'bg02.png', path: 'bg02.png' },
                { id: 3, preview: 'bg03.png', path: 'bg03.png' },
                { id: 4, preview: 'bg04.png', path: 'bg04.png' },
                { id: 5, preview: 'bg05.png', path: 'bg05.png' },
                { id: 6, preview: 'bg06.png', path: 'bg06.png' },
                { id: 7, preview: 'bg07.png', path: 'bg07.png' },
                { id: 8, preview: 'bg08.png', path: 'bg08.png' },
                { id: 9, preview: 'bg09.png', path: 'bg09.png' },
                { id: 10, preview: 'bg10.png', path: 'bg10.png' },
                { id: 11, preview: 'bg11.png', path: 'bg11.png' },
                { id: 12, preview: 'bg12.png', path: 'bg12.png' },
                { id: 13, preview: 'bg13.png', path: 'bg13.png' },
                { id: 14, preview: 'bg14.png', path: 'bg14.png' },
                { id: 15, preview: 'bg15.png', path: 'bg15.png' },
                { id: 16, preview: 'bg16.png', path: 'bg16.png' },
                { id: 17, preview: 'bg17.png', path: 'bg17.png' },
                { id: 18, preview: 'bg18.png', path: 'bg18.png' },
                { id: 19, preview: 'bg19.png', path: 'bg19.png' },
                { id: 20, preview: 'bg20.png', path: 'bg20.png' },
                { id: 21, preview: 'bg21.png', path: 'bg21.png' },
                { id: 22, preview: 'bg22.png', path: 'bg22.png' },
                { id: 23, preview: 'bg23.png', path: 'bg23.png' },
                { id: 24, preview: 'bg24.png', path: 'bg24.png' },
                { id: 25, preview: 'bg25.png', path: 'bg25.png' },
                { id: 26, preview: 'bg26.png', path: 'bg26.png' },
                { id: 27, preview: 'bg27.png', path: 'bg27.png' },
                { id: 28, preview: 'bg28.png', path: 'bg28.png' },
                { id: 29, preview: 'bg29.png', path: 'bg29.png' },
                { id: 30, preview: 'bg30.png', path: 'bg30.png' },
              ],
              count: 30,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cover.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 19,
              hour_startY: 18,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 19,
              minute_startY: 197,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: 0,
              src: 'coveraod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 18,
              hour_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 22,
              minute_startY: 198,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}