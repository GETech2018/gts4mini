﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stress_icon_img = ''
        let normal_stress_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 325,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stats_white_percent.png',
              unit_tc: 'stats_white_percent.png',
              unit_en: 'stats_white_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 325,
              image_array: ["battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png","battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 52,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stats_white_percent.png',
              unit_tc: 'stats_white_percent.png',
              unit_en: 'stats_white_percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 78,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png"],
              image_length: 13,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 29,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stats_white_degree_f.png',
              unit_tc: 'stats_white_degree_f.png',
              unit_en: 'stats_white_degree_f.png',
              negative_image: 'stats_white_negative.png',
              invalid_image: 'stats_white_negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 52,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stats_white_degree_f.png',
              unit_tc: 'stats_white_degree_f.png',
              unit_en: 'stats_white_degree_f.png',
              negative_image: 'stats_white_negative.png',
              invalid_image: 'stats_white_negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 29,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stats_white_degree_f.png',
              unit_tc: 'stats_white_degree_f.png',
              unit_en: 'stats_white_degree_f.png',
              negative_image: 'stats_white_negative.png',
              invalid_image: 'stats_white_negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 141,
              y: 24,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 322,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 325,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 288,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stats_white_mi.png',
              unit_tc: 'stats_white_mi.png',
              unit_en: 'stats_white_mi.png',
              imperial_unit_sc: 'stats_white_mi.png',
              imperial_unit_tc: 'stats_white_mi.png',
              imperial_unit_en: 'stats_white_mi.png',
              dot_image: 'stats_white_decimal_skinny.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 283,
              src: 'distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 283,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 288,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 283,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 288,
              font_array: ["stats_white_0.png","stats_white_1.png","stats_white_2.png","stats_white_3.png","stats_white_4.png","stats_white_5.png","stats_white_6.png","stats_white_7.png","stats_white_8.png","stats_white_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 161,
              y: 359,
              src: 'locked.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 269,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 293,
              src: 'bluetooth_disconnected.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 246,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 291,
              am_y: 107,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 291,
              pm_y: 208,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 107,
              hour_array: ["clock_0.png","clock_1.png","clock_2.png","clock_3.png","clock_4.png","clock_5.png","clock_6.png","clock_7.png","clock_8.png","clock_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 172,
              minute_startY: 107,
              minute_array: ["clock_0.png","clock_1.png","clock_2.png","clock_3.png","clock_4.png","clock_5.png","clock_6.png","clock_7.png","clock_8.png","clock_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 102,
              src: 'white_divider.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 6,
              y: 73,
              week_en: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_tc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_sc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 130,
              month_startY: 244,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 244,
              day_sc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_tc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_en_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 70,
              w: 24,
              h: 150,
              src: 'transparent.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 70,
              w: 24,
              h: 150,
              src: 'transparent.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 10,
              w: 165,
              h: 80,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 319,
              w: 85,
              h: 35,
              src: 'transparent.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 275,
              w: 95,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 275,
              w: 80,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 276,
              w: 82,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 305,
              src: 'heart_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 300,
              font_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 291,
              am_y: 107,
              am_sc_path: 'aod_AM.png',
              am_en_path: 'aod_AM.png',
              pm_x: 291,
              pm_y: 208,
              pm_sc_path: 'aod_PM.png',
              pm_en_path: 'aod_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 107,
              hour_array: ["aod_0.png","aod_1.png","aod_2.png","aod_3.png","aod_4.png","aod_5.png","aod_6.png","aod_7.png","aod_8.png","aod_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 172,
              minute_startY: 107,
              minute_array: ["aod_0.png","aod_1.png","aod_2.png","aod_3.png","aod_4.png","aod_5.png","aod_6.png","aod_7.png","aod_8.png","aod_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 102,
              src: 'aod_divider.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 6,
              y: 73,
              week_en: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_tc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_sc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 130,
              month_startY: 244,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 244,
              day_sc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_tc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_en_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  