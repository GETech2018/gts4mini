﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg_new-04.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 231,
              day_startY: 337,
              day_sc_array: ["Asset_66.png","Asset_67.png","Asset_68.png","Asset_69.png","Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png"],
              day_tc_array: ["Asset_66.png","Asset_67.png","Asset_68.png","Asset_69.png","Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png"],
              day_en_array: ["Asset_66.png","Asset_67.png","Asset_68.png","Asset_69.png","Asset_70.png","Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 173,
              month_startY: 337,
              month_sc_array: ["Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png"],
              month_tc_array: ["Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png"],
              month_en_array: ["Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 302,
              font_array: ["Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png","Asset_23.png","Asset_24.png","Asset_25.png","Asset_26.png","Asset_27.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 302,
              font_array: ["Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png","Asset_23.png","Asset_24.png","Asset_25.png","Asset_26.png","Asset_27.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Asset_29.png',
              unit_tc: 'Asset_29.png',
              unit_en: 'Asset_29.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 302,
              font_array: ["Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png","Asset_23.png","Asset_24.png","Asset_25.png","Asset_26.png","Asset_27.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 14,
              hour_array: ["Asset_7.png","Asset_8.png","Asset_9.png","Asset_10.png","Asset_11.png","Asset_12.png","Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Asset_17.png',
              hour_unit_tc: 'Asset_17.png',
              hour_unit_en: 'Asset_17.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Asset_7.png","Asset_8.png","Asset_9.png","Asset_10.png","Asset_11.png","Asset_12.png","Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg_aod2-05.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 302,
              font_array: ["Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png","Asset_46.png","Asset_47.png","Asset_48.png","Asset_49.png","Asset_50.png","Asset_51.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 302,
              font_array: ["Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png","Asset_46.png","Asset_47.png","Asset_48.png","Asset_49.png","Asset_50.png","Asset_51.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Asset_52.png',
              unit_tc: 'Asset_52.png',
              unit_en: 'Asset_52.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 302,
              font_array: ["Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png","Asset_46.png","Asset_47.png","Asset_48.png","Asset_49.png","Asset_50.png","Asset_51.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 14,
              hour_array: ["Asset_31.png","Asset_32.png","Asset_33.png","Asset_34.png","Asset_35.png","Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Asset_41.png',
              hour_unit_tc: 'Asset_41.png',
              hour_unit_en: 'Asset_41.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Asset_31.png","Asset_32.png","Asset_33.png","Asset_34.png","Asset_35.png","Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}