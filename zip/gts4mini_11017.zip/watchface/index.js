﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let editableZone_1_step_circle_scale = null;
        let editGroup_1  = ''
        let editGroup_2  = ''
        let mask = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextRotate = new Array(5);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 12;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 20;
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let editableTimePointers = ''
        let editableTimePointers_cover_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'BG0.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            let screenType = hmSetting.getScreenType();            
            const step = hmSensor.createSensor(hmSensor.id.STEP);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 117,
              y: 64,
              w: 100,
              h: 100,
              select_image: 'Active_area.png',
              un_select_image: 'Unactive_area.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
              ],
              count: 3,
              tips_BG: 'BG_Tooltips_1.png',
              tips_x: -24,
              tips_y: -30,
              tips_width: 150,
              tips_margin: 6,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                // editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 168,
                  // center_y: 114,
                  // start_angle: 26,
                  // end_angle: 334,
                  // radius: 40,
                  // line_width: 5,
                  // line_cap: Rounded,
                  // color: 0xFFB7F397,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 168,
                  center_y: 114,
                  start_angle: 26,
                  end_angle: 334,
                  radius: 38,
                  line_width: 5,
                  corner_flag: 0,
                  color: 0xFFB7F397,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 138,
                  y: 100,
                  font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 152,
                  y: 63,
                  src: 'Step_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 144,
                  y: 100,
                  font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 152,
                  y: 63,
                  src: 'Ccal_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 150,
                  y: 100,
                  font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 152,
                  y: 63,
                  src: 'Heart_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 40,
              y: 142,
              w: 100,
              h: 100,
              select_image: 'Active_area.png',
              un_select_image: 'Unactive_area.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(2)_DISTANCE.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
              ],
              count: 2,
              tips_BG: 'BG_Tooltips_1.png',
              tips_x: -26,
              tips_y: -28,
              tips_width: 150,
              tips_margin: 6,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 64,
                  y: 179,
                  font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
                  padding: false,
                  h_space: -2,
                  dot_image: 'Separate_date.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 74,
                  y: 142,
                  src: 'Dist_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 74,
                  y: 142,
                  image_array: ["Weather_icon_00.png","Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 67,
                  y: 179,
                  font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'Weather_deg.png',
                  unit_tc: 'Weather_deg.png',
                  unit_en: 'Weather_deg.png',
                  negative_image: 'Weather_neg.png',
                  invalid_image: '25_weather.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Area_1.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 112,
              y: 363,
              src: 'icon_bl_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 363,
              src: 'icon_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 363,
              src: 'icon_bl_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 363,
              src: 'icon_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 257,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 152,
              y: 217,
              src: 'sp02_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 224,
              y: 198,
              week_en: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              week_tc: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              week_sc: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 172,
              day_sc_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              day_tc_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              day_en_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              day_zero: 1,
              day_space: -1,
              day_unit_sc: 'Separate_date.png',
              day_unit_tc: 'Separate_date.png',
              day_unit_en: 'Separate_date.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 250,
              month_startY: 172,
              month_sc_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              month_tc_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              month_en_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 231,
              y: 142,
              src: 'Calendar_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 168,
              // center_y: 192,
              // start_angle: -70,
              // end_angle: 70,
              // radius: 176,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFF55624C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 168,
              center_y: 192,
              start_angle: -70,
              end_angle: 70,
              radius: 174,
              line_width: 4,
              corner_flag: 0,
              color: 0xFF55624C,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 26,
              // y: 50,
              // font_array: ["Bat_0.png","Bat_1.png","Bat_2.png","Bat_3.png","Bat_4.png","Bat_5.png","Bat_6.png","Bat_7.png","Bat_8.png","Bat_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -45,
              // unit_en: 'Percent.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'Bat_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'Bat_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'Bat_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'Bat_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'Bat_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'Bat_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'Bat_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'Bat_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'Bat_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'Bat_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 336,
                h: 384,
                center_x: 26,
                center_y: 50,
                pos_x: 26,
                pos_y: 50,
                angle: -45,
                src: 'Bat_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              center_x: 26,
              center_y: 50,
              pos_x: 26,
              pos_y: 50,
              angle: -45,
              src: 'Percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };



            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 300,
              month_sc_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              month_tc_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              month_en_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 137,
              day_startY: 300,
              day_sc_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              day_tc_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              day_en_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              day_zero: 1,
              day_space: -1,
              day_unit_sc: 'Separate_date.png',
              day_unit_tc: 'Separate_date.png',
              day_unit_en: 'Separate_date.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 145,
              y: 330,
              week_en: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              week_tc: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              week_sc: ["ru_01_mon.png","ru_02_tue.png","ru_03_wed.png","ru_04_Thu.png","ru_05_fri.png","ru_06_sat.png","ru_07_sun.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 137,
              hour_startY: 26,
              hour_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_unit_sc: 'Separate.png',
              hour_unit_tc: 'Separate.png',
              hour_unit_en: 'Separate.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 173,
              minute_startY: 26,
              minute_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_min.png',
              minute_centerX: 168,
              minute_centerY: 192,
              minute_posX: 3,
              minute_posY: 149,
              minute_cover_path: 'Pin.png',
              minute_cover_x: 163,
              minute_cover_y: 187,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour.png',
              hour_centerX: 168,
              hour_centerY: 192,
              hour_posX: 17,
              hour_posY: 105,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 168,
                    centerY: 192,
                    posX: 1,
                    posY: 153,
                    path: 'Hand_sec.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 192,
                    posX: 17,
                    posY: 105,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 192,
                    posX: 3,
                    posY: 149,
                    path: 'Hand_min.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 168,
                    centerY: 192,
                    posX: 1,
                    posY: 153,
                    path: 'Hand_sec.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 192,
                    posX: 17,
                    posY: 105,
                    path: 'Hand_hour_filled.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 192,
                    posX: 3,
                    posY: 149,
                    path: 'Hand_min.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: 'Hands_frame.png',
              tips_x: 92,
              tips_y: 332,
              tips_bg: 'BG_Tooltips_1.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            editableTimePointers_cover_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 187,
              src: 'Pin.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth off,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Bluetooth on,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth off"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth on"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            function text_update() {

              console.log('update text rotate BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 26 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 26 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_1_step = progressStep;

                if (editableZone_1_step_circle_scale) {

                  // editableZone_1_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_step * 100);
                  if (editableZone_1_step_circle_scale) {
                    editableZone_1_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 168,
                      center_y: 114,
                      start_angle: 26,
                      end_angle: 334,
                      radius: 38,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFB7F397,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 168,
                      center_y: 192,
                      start_angle: -70,
                      end_angle: 70,
                      radius: 174,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFF55624C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}