try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_7cb3f8ac87494933be9adf320c3e160a = '';
        let normal$_$text_8a20630cf5ec453d97ae31ecc7770600 = '';
        let normal$_$text_4745dbed04ab400583682a8fb6bb8976 = '';
        let normal$_$text_e54921f279ec46f9ad1b00ee34a73562 = '';
        let normal$_$text_966a1d717e4b4072b5465dcc5235ea49 = '';
        let idle$_$text_22bceb64af174fc1843bff468d12a169 = '';
        let calorieSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 16,
                    hour_startY: 147,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 127,
                    minute_startY: 145,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 257,
                    second_startY: 177,
                    second_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_7cb3f8ac87494933be9adf320c3e160a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 109,
                    y: 141,
                    w: 10,
                    h: 40,
                    text: ':',
                    color: '0xFFffffff',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_8a20630cf5ec453d97ae31ecc7770600 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 234,
                    y: 169,
                    w: 10,
                    h: 40,
                    text: ':',
                    color: '0xFFffffff',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 52,
                    y: 19,
                    image_array: [
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 201,
                    y: 19,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_4745dbed04ab400583682a8fb6bb8976 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 261,
                    y: 14,
                    w: 100,
                    h: 40,
                    text: '%',
                    color: '0xFFffffff',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 229,
                    year_startY: 79,
                    year_sc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    year_tc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    year_en_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    year_align: hmUI.align.LEFT,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_startX: 169,
                    month_startY: 79,
                    month_sc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    month_tc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    month_en_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    month_unit_sc: '33.png',
                    month_unit_tc: '33.png',
                    month_unit_en: '33.png',
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 110,
                    day_startY: 79,
                    day_sc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_tc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_en_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_unit_sc: '34.png',
                    day_unit_tc: '34.png',
                    day_unit_en: '34.png',
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 15,
                    y: 80,
                    week_en: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_e54921f279ec46f9ad1b00ee34a73562 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 87,
                    y: 258,
                    w: 100,
                    h: 40,
                    text: '[CAL]Kcal',
                    color: '0xFFffffff',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_966a1d717e4b4072b5465dcc5235ea49 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 87,
                    y: 325,
                    w: 100,
                    h: 40,
                    text: '[HR]BPM',
                    color: '0xFFffffff',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 16,
                    hour_startY: 147,
                    hour_array: [
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 127,
                    minute_startY: 145,
                    minute_array: [
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_22bceb64af174fc1843bff468d12a169 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 109,
                    y: 141,
                    w: 100,
                    h: 40,
                    text: ':',
                    color: '0xFF535151',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_e54921f279ec46f9ad1b00ee34a73562.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }Kcal` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_966a1d717e4b4072b5465dcc5235ea49.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }BPM` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_7cb3f8ac87494933be9adf320c3e160a.setProperty(hmUI.prop.MORE, { text: `:` });
                        normal$_$text_8a20630cf5ec453d97ae31ecc7770600.setProperty(hmUI.prop.MORE, { text: `:` });
                        normal$_$text_4745dbed04ab400583682a8fb6bb8976.setProperty(hmUI.prop.MORE, { text: `%` });
                        normal$_$text_e54921f279ec46f9ad1b00ee34a73562.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }Kcal` });
                        normal$_$text_966a1d717e4b4072b5465dcc5235ea49.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }BPM` });
                        idle$_$text_22bceb64af174fc1843bff468d12a169.setProperty(hmUI.prop.MORE, { text: `:` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}