﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'fon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 276,
              font_array: ["wnum-00.png","wnum-01.png","wnum-02.png","wnum-03.png","wnum-04.png","wnum-05.png","wnum-06.png","wnum-07.png","wnum-08.png","wnum-09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'w-gre.png',
              unit_tc: 'w-gre.png',
              unit_en: 'w-gre.png',
              negative_image: 'w--.png',
              invalid_image: 'w--.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 276,
              font_array: ["wnum-00.png","wnum-01.png","wnum-02.png","wnum-03.png","wnum-04.png","wnum-05.png","wnum-06.png","wnum-07.png","wnum-08.png","wnum-09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'w-gre.png',
              unit_tc: 'w-gre.png',
              unit_en: 'w-gre.png',
              negative_image: 'w--.png',
              invalid_image: 'w--.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 247,
              y: 276,
              src: 'w-sl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 222,
              font_array: ["wnum-00.png","wnum-01.png","wnum-02.png","wnum-03.png","wnum-04.png","wnum-05.png","wnum-06.png","wnum-07.png","wnum-08.png","wnum-09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'w-gre.png',
              unit_tc: 'w-gre.png',
              unit_en: 'w-gre.png',
              negative_image: 'w--.png',
              invalid_image: 'w--.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 250,
              y: 192,
              image_array: ["wt000.png","wt001.png","wt002.png","wt003.png","wt004.png","wt005.png","wt006.png","wt007.png","wt008.png","wt009.png","wt010.png","wt011.png","wt012.png","wt013.png","wt014.png","wt015.png","wt016.png","wt017.png","wt018.png","wt019.png","wt020.png","wt021.png","wt022.png","wt023.png","wt024.png","wt025.png","wt026.png","wt027.png","wt028.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 242,
              font_array: ["wnum-00.png","wnum-01.png","wnum-02.png","wnum-03.png","wnum-04.png","wnum-05.png","wnum-06.png","wnum-07.png","wnum-08.png","wnum-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bat.png',
              unit_tc: 'bat.png',
              unit_en: 'bat.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 198,
              font_array: ["wnum-00.png","wnum-01.png","wnum-02.png","wnum-03.png","wnum-04.png","wnum-05.png","wnum-06.png","wnum-07.png","wnum-08.png","wnum-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'heart.png',
              unit_tc: 'heart.png',
              unit_en: 'heart.png',
              invalid_image: 'w--.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 154,
              font_array: ["wnum-00.png","wnum-01.png","wnum-02.png","wnum-03.png","wnum-04.png","wnum-05.png","wnum-06.png","wnum-07.png","wnum-08.png","wnum-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'step.png',
              unit_tc: 'step.png',
              unit_en: 'step.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 264,
              month_startY: 30,
              month_sc_array: ["date-00.png","date-01.png","date-02.png","date-03.png","date-04.png","date-05.png","date-06.png","date-07.png","date-08.png","date-09.png"],
              month_tc_array: ["date-00.png","date-01.png","date-02.png","date-03.png","date-04.png","date-05.png","date-06.png","date-07.png","date-08.png","date-09.png"],
              month_en_array: ["date-00.png","date-01.png","date-02.png","date-03.png","date-04.png","date-05.png","date-06.png","date-07.png","date-08.png","date-09.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 30,
              day_sc_array: ["date-00.png","date-01.png","date-02.png","date-03.png","date-04.png","date-05.png","date-06.png","date-07.png","date-08.png","date-09.png"],
              day_tc_array: ["date-00.png","date-01.png","date-02.png","date-03.png","date-04.png","date-05.png","date-06.png","date-07.png","date-08.png","date-09.png"],
              day_en_array: ["date-00.png","date-01.png","date-02.png","date-03.png","date-04.png","date-05.png","date-06.png","date-07.png","date-08.png","date-09.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'date-dot.png',
              day_unit_tc: 'date-dot.png',
              day_unit_en: 'date-dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 30,
              week_en: ["wek-01.png","wek-02.png","wek-03.png","wek-04.png","wek-05.png","wek-06.png","wek-07.png"],
              week_tc: ["wek-01.png","wek-02.png","wek-03.png","wek-04.png","wek-05.png","wek-06.png","wek-07.png"],
              week_sc: ["wek-01.png","wek-02.png","wek-03.png","wek-04.png","wek-05.png","wek-06.png","wek-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 22,
              hour_array: ["cl-00.png","cl-01.png","cl-02.png","cl-03.png","cl-04.png","cl-05.png","cl-06.png","cl-07.png","cl-08.png","cl-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 158,
              minute_startY: 80,
              minute_array: ["min-00.png","min-01.png","min-02.png","min-03.png","min-04.png","min-05.png","min-06.png","min-07.png","min-08.png","min-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 22,
              hour_array: ["aod_clk00.png","aod_clk01.png","aod_clk02.png","aod_clk03.png","aod_clk04.png","aod_clk05.png","aod_clk06.png","aod_clk07.png","aod_clk08.png","aod_clk09.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 158,
              minute_startY: 80,
              minute_array: ["aod_min00.png","aod_min01.png","aod_min02.png","aod_min03.png","aod_min04.png","aod_min05.png","aod_min06.png","aod_min07.png","aod_min08.png","aod_min09.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}