﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'new+-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 202,
              font_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'wendu.png',
              unit_tc: 'wendu.png',
              unit_en: 'wendu.png',
              negative_image: 'wgang+.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 230,
              y: 143,
              image_array: ["t00.png","t01.png","t02.png","t03.png","t04.png","t05.png","t06.png","t07.png","t08.png","t09.png","t10.png","t11.png","t12.png","t13.png","t14.png","t15.png","t16.png","t17.png","t18.png","t19.png","t20.png","t21.png","t22.png","t23.png","t24.png","t25.png","t26.png","t27.png","t28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 58,
              font_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 32,
              y: 292,
              week_en: ["x1.png","x2.png","x3.png","x4.png","x5.png","x6.png","x7.png"],
              week_tc: ["x1.png","x2.png","x3.png","x4.png","x5.png","x6.png","x7.png"],
              week_sc: ["x1.png","x2.png","x3.png","x4.png","x5.png","x6.png","x7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 232,
              day_startY: 292,
              day_sc_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              day_tc_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              day_en_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 151,
              month_startY: 292,
              month_sc_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              month_tc_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              month_en_array: ["w0x.png","w1x.png","w2x.png","w3x.png","w4x.png","w5x.png","w6x.png","w7x.png","w8x.png","w9x.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'wgang.png',
              month_unit_tc: 'wgang.png',
              month_unit_en: 'wgang.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'wgang.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 56,
              hour_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              hour_zero: 1,
              hour_space: 16,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 54,
              minute_startY: 152,
              minute_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              minute_zero: 1,
              minute_space: 16,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  