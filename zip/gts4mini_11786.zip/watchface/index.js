﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let idle_image_img = ''
        let idle_temperature_icon_img = ''
        let editableTimePointers = ''
        let editableTimePointers_cover_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 336,
              // h: 388,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'MAIN1.png', path: 'MAIN1.png' },
                { id: 2, preview: 'MAIN2.png', path: 'MAIN2.png' },
                { id: 3, preview: 'MAIN3.png', path: 'MAIN3.png' },
                { id: 4, preview: 'MAIN4.png', path: 'MAIN4.png' },
                { id: 5, preview: 'MAIN5.png', path: 'MAIN5.png' },
                { id: 6, preview: 'MAIN6.png', path: 'MAIN6.png' },
                { id: 7, preview: 'MAIN7.png', path: 'MAIN7.png' },
              ],
              count: 7,
              default_id: 1,
              fg: 'H_L.png',
              tips_bg: 'TIPS.png',
              tips_x: 113,
              tips_y: 295,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'MAIN0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'IMG_0333.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 168,
                    centerY: 194,
                    posX: 12,
                    posY: 125,
                    path: 'SECO.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 194,
                    posX: 43,
                    posY: 98,
                    path: 'HOUR1.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 194,
                    posX: 34,
                    posY: 117,
                    path: 'MINU1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 168,
                    centerY: 194,
                    posX: 12,
                    posY: 125,
                    path: 'SECO.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 194,
                    posX: 43,
                    posY: 98,
                    path: 'HOUR2.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 194,
                    posX: 34,
                    posY: 117,
                    path: 'MINU2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 168,
                    centerY: 194,
                    posX: 12,
                    posY: 125,
                    path: 'SECO.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 194,
                    posX: 43,
                    posY: 98,
                    path: 'HOUR3.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 194,
                    posX: 34,
                    posY: 117,
                    path: 'MINU3.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 168,
                    centerY: 194,
                    posX: 12,
                    posY: 125,
                    path: 'SECO.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 194,
                    posX: 43,
                    posY: 98,
                    path: 'HOUR4.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 194,
                    posX: 34,
                    posY: 117,
                    path: 'MINU4.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 168,
                    centerY: 194,
                    posX: 12,
                    posY: 125,
                    path: 'SECO.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 194,
                    posX: 43,
                    posY: 98,
                    path: 'HOUR5.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 194,
                    posX: 34,
                    posY: 117,
                    path: 'MINU5.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 168,
                    centerY: 194,
                    posX: 12,
                    posY: 125,
                    path: 'SECO.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 194,
                    posX: 43,
                    posY: 98,
                    path: 'HOUR6.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 194,
                    posX: 34,
                    posY: 117,
                    path: 'MINU6.png',
                  },
                  preview: 'pointer_edit_6_preview.png',
                },
                {
                  id: 7,
                  second: {
                    centerX: 168,
                    centerY: 194,
                    posX: 12,
                    posY: 125,
                    path: 'SECO.png',
                  },
                  hour: {
                    centerX: 168,
                    centerY: 194,
                    posX: 43,
                    posY: 98,
                    path: 'HOUR7.png',
                  },
                  minute: {
                    centerX: 168,
                    centerY: 194,
                    posX: 34,
                    posY: 117,
                    path: 'MINU7.png',
                  },
                  preview: 'pointer_edit_7_preview.png',
                },
              ],
              count: 7,
              default_id: 1,
              fg: 'H_L_S.png',
              tips_x: 113,
              tips_y: 295,
              tips_bg: 'TIPS.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            editableTimePointers_cover_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 182,
              src: 'SECONO.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}