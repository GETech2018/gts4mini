﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'BG003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 80,
              src: 'bt2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 260,
              y: 80,
              src: 'al2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 274,
              font_array: ["600.png","601.png","602.png","603.png","604.png","605.png","606.png","607.png","608.png","609.png"],
              padding: false,
              h_space: 0,
              unit_sc: '610.png',
              unit_tc: '610.png',
              unit_en: '610.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 317,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 80,
              font_array: ["600.png","601.png","602.png","603.png","604.png","605.png","606.png","607.png","608.png","609.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Gradi.png',
              unit_tc: 'Gradi.png',
              unit_en: 'Gradi.png',
              negative_image: 'Meno.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 65,
              src: '0024.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 80,
              font_array: ["600.png","601.png","602.png","603.png","604.png","605.png","606.png","607.png","608.png","609.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Gradi.png',
              unit_tc: 'Gradi.png',
              unit_en: 'Gradi.png',
              negative_image: 'Meno.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 65,
              src: '0023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 98,
              font_array: ["600.png","601.png","602.png","603.png","604.png","605.png","606.png","607.png","608.png","609.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Gradi.png',
              unit_tc: 'Gradi.png',
              unit_en: 'Gradi.png',
              negative_image: 'Meno.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 37,
              image_array: ["w_61.png","w_0062.png","w_63.png","w_64.png","w_65.png","w_66.png","w_67.png","w_68.png","w_69.png","w_70.png","w_71.png","w_72.png","w_73.png","w_74.png","w_75.png","w_76.png","w_77.png","w_78.png","w_79.png","w_80.png","w_81.png","w_82.png","w_83.png","w_84.png","w_85.png","w_86.png","w_87.png","w_88.png","w_89.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 200,
              h: 40,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 137,
              y: 130,
              week_en: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 165,
              month_sc_array: ["400.png","401.png","402.png","403.png","404.png","405.png","406.png","407.png","408.png","409.png"],
              month_tc_array: ["400.png","401.png","402.png","403.png","404.png","405.png","406.png","407.png","408.png","409.png"],
              month_en_array: ["400.png","401.png","402.png","403.png","404.png","405.png","406.png","407.png","408.png","409.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 132,
              day_startY: 165,
              day_sc_array: ["400.png","401.png","402.png","403.png","404.png","405.png","406.png","407.png","408.png","409.png"],
              day_tc_array: ["400.png","401.png","402.png","403.png","404.png","405.png","406.png","407.png","408.png","409.png"],
              day_en_array: ["400.png","401.png","402.png","403.png","404.png","405.png","406.png","407.png","408.png","409.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '412.png',
              day_unit_tc: '412.png',
              day_unit_en: '412.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 290,
              font_array: ["600.png","601.png","602.png","603.png","604.png","605.png","606.png","607.png","608.png","609.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 32,
              y: 312,
              image_array: ["Zone01.png","Zone02.png","Zone03.png","Zone04.png","Zone05.png","Zone06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 4,
              hour_startY: 147,
              hour_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 217,
              minute_startY: 147,
              minute_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 135,
              second_startY: 205,
              second_array: ["n00.png","n01.png","n02.png","n03.png","n04.png","n05.png","n06.png","n07.png","n08.png","n09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 111,
              src: '0050.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 290,
              font_array: ["600.png","601.png","602.png","603.png","604.png","605.png","606.png","607.png","608.png","609.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 150,
              src: 'bt2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 150,
              src: 'al2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 274,
              font_array: ["600.png","601.png","602.png","603.png","604.png","605.png","606.png","607.png","608.png","609.png"],
              padding: false,
              h_space: 0,
              unit_sc: '610.png',
              unit_tc: '610.png',
              unit_en: '610.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 317,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 140,
              hour_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: '2.png',
              hour_unit_tc: '2.png',
              hour_unit_en: '2.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 217,
              minute_startY: 147,
              minute_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 145,
              w: 115,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 145,
              w: 115,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 118,
              y: 70,
              w: 100,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 235,
              y: 280,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 285,
              w: 100,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 0,
              w: 150,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 334,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'camera.png',
              normal_src: 'camera.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'HidcameraScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 135,
              w: 100,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}