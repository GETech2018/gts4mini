﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let image_top_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg_garmin-03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 71,
              font_array: ["Asset_31.png","Asset_32.png","Asset_33.png","Asset_34.png","Asset_35.png","Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 36,
              src: 'Asset_44.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 8,
              image_array: ["Asset_48.png","Asset_49.png","Asset_50.png","Asset_51.png","Asset_52.png","Asset_53.png","Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 321,
              src: 'Asset_42.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 272,
              font_array: ["Asset_31.png","Asset_32.png","Asset_33.png","Asset_34.png","Asset_35.png","Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 277,
              day_startY: 182,
              day_sc_array: ["Asset_31.png","Asset_32.png","Asset_33.png","Asset_34.png","Asset_35.png","Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png"],
              day_tc_array: ["Asset_31.png","Asset_32.png","Asset_33.png","Asset_34.png","Asset_35.png","Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png"],
              day_en_array: ["Asset_31.png","Asset_32.png","Asset_33.png","Asset_34.png","Asset_35.png","Asset_36.png","Asset_37.png","Asset_38.png","Asset_39.png","Asset_40.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 196,
              month_startY: 182,
              month_sc_array: ["Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png","Asset_66.png","Asset_67.png","Asset_68.png","Asset_69.png"],
              month_tc_array: ["Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png","Asset_66.png","Asset_67.png","Asset_68.png","Asset_69.png"],
              month_en_array: ["Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png","Asset_66.png","Asset_67.png","Asset_68.png","Asset_69.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 152,
              week_en: ["Asset_12.png","Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png"],
              week_tc: ["Asset_12.png","Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png"],
              week_sc: ["Asset_12.png","Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 7,
              hour_array: ["Asset_1.png","Asset_2.png","Asset_3.png","Asset_4.png","Asset_5.png","Asset_6.png","Asset_7.png","Asset_8.png","Asset_9.png","Asset_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 37,
              minute_startY: 226,
              minute_array: ["Asset_1.png","Asset_2.png","Asset_3.png","Asset_4.png","Asset_5.png","Asset_6.png","Asset_7.png","Asset_8.png","Asset_9.png","Asset_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg_aod_garmin2-04.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12,
              hour_startY: 122,
              hour_array: ["Asset_76.png","Asset_77.png","Asset_78.png","Asset_79.png","Asset_80.png","Asset_81.png","Asset_82.png","Asset_83.png","Asset_84.png","Asset_85.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 206,
              minute_startY: 122,
              minute_array: ["Asset_76.png","Asset_77.png","Asset_78.png","Asset_79.png","Asset_80.png","Asset_81.png","Asset_82.png","Asset_83.png","Asset_84.png","Asset_85.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'skull_aod2-04.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'skull-04.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}