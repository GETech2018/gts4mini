try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 3,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 4,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 5,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 6,
                            'path': '14.png',
                            'preview': '15.png'
                        }
                    ],
                    count: 6,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 11,
                    hour_startY: 146,
                    hour_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    hour_space: 5,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 157,
                    minute_startY: 146,
                    minute_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    minute_space: 5,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 281,
                    second_startY: 210,
                    second_array: [
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    second_space: 5,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 256,
                    am_y: 163,
                    am_en_path: '36.png',
                    pm_x: 286,
                    pm_y: 163,
                    pm_en_path: '37.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 260,
                    y: 45,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '48.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 238,
                    y: 45,
                    src: '49.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 83,
                    month_startY: 45,
                    month_sc_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    month_tc_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    month_en_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    month_align: hmUI.align.RIGHT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 3,
                    month_is_character: false,
                    day_startX: 31,
                    day_startY: 45,
                    day_sc_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    day_tc_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    day_en_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 3,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 55,
                    y: 313,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '50.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 22,
                    y: 312,
                    src: '51.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 274,
                    y: 97,
                    src: '52.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 274,
                    y: 313,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '55.png',
                    unit_tc: '55.png',
                    unit_en: '55.png',
                    negative_image: '54.png',
                    invalid_image: '53.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 232,
                    y: 310,
                    image_array: [
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 131,
                    y: 45,
                    week_en: [
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 66,
                    y: 45,
                    src: '92.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 140,
                    y: 313,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '93.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 117,
                    y: 310,
                    src: '94.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 116,
                    y: 150,
                    src: '95.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 11,
                    hour_startY: 146,
                    hour_array: [
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png'
                    ],
                    hour_space: 5,
                    hour_align: hmUI.align.RIGHT,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 157,
                    minute_startY: 146,
                    minute_array: [
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png'
                    ],
                    minute_space: 5,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    am_x: 286,
                    am_y: 163,
                    am_en_path: '106.png',
                    pm_x: 286,
                    pm_y: 163,
                    pm_en_path: '107.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 116,
                    y: 150,
                    src: '108.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}