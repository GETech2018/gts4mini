﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_system_lock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 1;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 38;
        let normal_distance_TextRotate_dot_width = 1;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_second = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'main2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 115,
              src: 'Ico1.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 239,
              y: 109,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 239,
              y: 133,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 145,
              y: 115,
              src: 'LOCK2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 211,
              font_array: ["Act_small_Font_01.png","Act_small_Font_02.png","Act_small_Font_03.png","Act_small_Font_04.png","Act_small_Font_05.png","Act_small_Font_06.png","Act_small_Font_07.png","Act_small_Font_08.png","Act_small_Font_09.png","Act_small_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 251,
              y: 149,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 77,
              y: 143,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 150,
              // y: 318,
              // font_array: ["0_Empty.png","1_Empty.png","2_Empty.png","3_Empty.png","4_Empty.png","5_Empty.png","6_Empty.png","7_Empty.png","8_Empty.png","9_Empty.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'dis_KM.png',
              // imperial_unit_en: 'dis_MI.png',
              // invalid_image: '0_Empty.png',
              // dot_image: '0_Empty.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = '1_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = '2_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = '3_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = '4_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = '5_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = '6_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = '7_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = '8_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = '9_Empty.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 336,
                h: 384,
                center_x: 150,
                center_y: 318,
                pos_x: 150,
                pos_y: 318,
                angle: 0,
                src: '0_Empty.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              center_x: 150,
              center_y: 318,
              pos_x: 150,
              pos_y: 318,
              angle: 0,
              src: 'dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'dis_MI.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 292,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'Act_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 296,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 245,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 239,
              y: 287,
              image_array: ["Cal_icon_01.png","Cal_icon_02.png","Cal_icon_03.png","Cal_icon_04.png","Cal_icon_05.png","Cal_icon_06.png","Cal_icon_07.png","Cal_icon_08.png","Cal_icon_09.png","Cal_icon_10.png","Cal_icon_11.png","Cal_icon_12.png","Cal_icon_13.png","Cal_icon_14.png"],
              image_length: 14,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 139,
              y: 249,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 24,
              y: 245,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 287,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png","Step_icon_10.png","Step_icon_11.png","Step_icon_12.png","Step_icon_13.png","Step_icon_14.png"],
              image_length: 14,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 246,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 56,
              font_array: ["Act_small_Font_01.png","Act_small_Font_02.png","Act_small_Font_03.png","Act_small_Font_04.png","Act_small_Font_05.png","Act_small_Font_06.png","Act_small_Font_07.png","Act_small_Font_08.png","Act_small_Font_09.png","Act_small_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 29,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png","Batt_icon_11.png","Batt_icon_12.png","Batt_icon_13.png","Batt_icon_14.png"],
              image_length: 14,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 63,
              // center_y: 63,
              // start_angle: 253,
              // end_angle: -68,
              // radius: 34,
              // line_width: 7,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 63,
              center_y: 63,
              start_angle: 253,
              end_angle: -68,
              radius: 31,
              line_width: 7,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 29,
              src: 'TopHeart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 119,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Bpm.png',
              unit_tc: 'Bpm.png',
              unit_en: 'Bpm.png',
              invalid_image: 'Act_Font_01.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 111,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 32,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 67,
              month_sc_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_tc_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_en_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 117,
              day_startY: 65,
              day_sc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_tc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_en_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 83,
              y: 58,
              src: 'shadow2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 278,
              y: 121,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 145,
              minute_startY: 173,
              minute_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 173,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 32,
              hour_startY: 173,
              hour_array: ["Time_H_Font_01.png","Time_H_Font_02.png","Time_H_Font_03.png","Time_H_Font_04.png","Time_H_Font_05.png","Time_H_Font_06.png","Time_H_Font_07.png","Time_H_Font_08.png","Time_H_Font_09.png","Time_H_Font_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 123,
              y: 172,
              src: 'TIME_DOT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 150,
              second_startY: 244,
              second_array: ["sec0.png","sec1.png","sec2.png","sec3.png","sec4.png","sec5.png","sec6.png","sec7.png","sec8.png","sec9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 64,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 139,
              month_startY: 37,
              month_sc_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_tc_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_en_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 117,
              day_startY: 65,
              day_sc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_tc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_en_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 83,
              y: 58,
              src: 'shadow2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 145,
              minute_startY: 173,
              minute_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 173,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 32,
              hour_startY: 173,
              hour_array: ["Time_H_Font_01.png","Time_H_Font_02.png","Time_H_Font_03.png","Time_H_Font_04.png","Time_H_Font_05.png","Time_H_Font_06.png","Time_H_Font_07.png","Time_H_Font_08.png","Time_H_Font_09.png","Time_H_Font_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 123,
              y: 172,
              src: 'TIME_DOT.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 177,
              w: 83,
              h: 53,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 177,
              w: 83,
              h: 53,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 211,
              y: 107,
              w: 47,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 102,
              w: 49,
              h: 47,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 184,
              w: 61,
              h: 49,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 290,
              w: 67,
              h: 64,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 10,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 150 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 150 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, '0_Empty.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 150 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 150 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, '0_Empty.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 63,
                      center_y: 63,
                      start_angle: 253,
                      end_angle: -68,
                      radius: 31,
                      line_width: 7,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}