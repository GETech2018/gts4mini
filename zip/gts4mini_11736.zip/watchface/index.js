﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_mirror = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_image_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = [' [ПН]', ' [ВТ]', ' [СР]', ' [ЧТ]', ' [ПТ]', ' [СБ]', ' [ВС]', ];
        let normal_digital_clock_img_time = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('user_script_start.js');
            // start user_script_start.js

const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;
let new_Timer = null;

if (new_Timer == null) { new_Timer = timer.createTimer(50, 1000, new_timer_update, {}); }

let bg_index = 0;



let t_counter_01 = 0;	  //счетчик таймера 1 (срабатывает с периодичностью 1000 мс)
let t_counter_02 = 0;	  //счетчик таймера переключений label_TXT
let g_counter_01 = 0;	  //vibro
//let limit_counter_02 = 3; //частота переключений label_TXT в секундах

let month_day_nums = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
let month_name = ['...', 'ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ', 'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ'];

const bg_list = [
'bg_01.png',
'bg_02.png',
];

let color_array_TXT = [0xFFDD2020, 0xFF00D8F8, 0xFFF8EF00, 0xFF00F85D, 0xFFB700CB, 0xFFFFFFFF];


//GTS4 mini
//16, 23, 24=short

function vibro(scene = 25) {
	
	vibrate.stop();
	vibrate.scene = scene;
	
	let stopDelay = 50;
	if (scene < 23 || scene > 25) stopDelay = 1220;
	vibrate.start();
	stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
}

function stopVibro() {
	vibrate.stop();
	timer.stopTimer(stopVibro_Timer);
}

//========================================================== BUTTON ===
function bg_switching() {
    bg_index++;
    if (bg_index >= bg_list.length) bg_index = 0;

	//vibro();
	colors_update();
}

function button_time() {
	g_counter_01++;
	vibro(23);
	
	//let label_TXT = String(g_counter_01); //'Num'
	//normal_dow_text_font.setProperty(hmUI.prop.TEXT, label_TXT);
	
	bg_switching();
}

//========================================================== COLORS ===

function colors_update() {
	
	normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
	//normal_system_clock_img.setProperty(hmUI.prop.SRC, ico_alarm_list[bg_index]);
	
	//let colorDay = color_LABEL[bg_index];
	//normal_dow_text_font.setProperty(hmUI.prop.COLOR, colorDay);
	//normal_city_name_text.setProperty(hmUI.prop.COLOR, colorDay);
}

//=========================================================== TIMER ===
function new_timer_update() {
	t_counter_01++;
	t_counter_02++;
	
	//if ( (t_counter_01 % 2 == 0)&&((t_counter_01 < t_counter_03 + limit_counter_03)) ) { label_switching(); }
	//if ( (t_counter_00 > 240) && (MENU_MODE == 1) ) MUNU_SWITCH();
	
	normal_image_img.setProperty(hmUI.prop.VISIBLE, (t_counter_01 % 2 == 0));
}

function formatNumber(num) {
	return num < 10 ? '0' + num : num.toString();
}
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 158,
              y: 282,
              src: 'icon_sleep.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 158,
              y: 254,
              src: 'icon_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 158,
              y: 224,
              src: 'icon_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_battery_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 168,
              // start_y: 375,
              // color: 0xFF00E1FF,
              // lenght: 89,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 343,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 372,
              src: 'power_cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 247,
              font_array: ["dm2_00.png","dm2_01.png","dm2_02.png","dm2_03.png","dm2_04.png","dm2_05.png","dm2_06.png","dm2_07.png","dm2_08.png","dm2_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dm2_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 218,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 218,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 247,
              font_array: ["dm1_00.png","dm1_01.png","dm1_02.png","dm1_03.png","dm1_04.png","dm1_05.png","dm1_06.png","dm1_07.png","dm1_08.png","dm1_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 58,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dws0_perc.png',
              unit_tc: 'dws0_perc.png',
              unit_en: 'dws0_perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 58,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dws0_C.png',
              unit_tc: 'dws0_C.png',
              unit_en: 'dws0_C.png',
              negative_image: 'dws0_minus.png',
              invalid_image: 'dws0_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 50,
              image_array: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 68,
              y: 10,
              w: 200,
              h: 26,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 128,
              src: 'db1_div.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 18,
              y: 108,
              w: 300,
              h: 20,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string:  [ПН],  [ВТ],  [СР],  [ЧТ],  [ПТ],  [СБ],  [ВС],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 132,
              hour_array: ["db1_00.png","db1_01.png","db1_02.png","db1_03.png","db1_04.png","db1_05.png","db1_06.png","db1_07.png","db1_08.png","db1_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 180,
              minute_startY: 132,
              minute_array: ["db1_00.png","db1_01.png","db1_02.png","db1_03.png","db1_04.png","db1_05.png","db1_06.png","db1_07.png","db1_08.png","db1_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 128,
              w: 264,
              h: 80,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 20,
              press_src: 'dummy.png',
              normal_src: 'dummy.png',
              click_func: (button_widget) => {
                button_time();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			/*normal_bg_day_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_day_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL, // | hmUI.show_level.ONLY_AOD
           });
		   

		   for (let i = 0; i < 31; i++) {
			label_days[i] = hmUI.createWidget(hmUI.widget.TEXT, {
					 x: 214,
					 y: 227,
					 w: 30,
					 h: 28,
					 text_size: 20,
					 text: String(i+1),
					 char_space: 0,
					 line_space: 0,
					 color: 0x00000000,
					 align_h: hmUI.align.CENTER_H,
					 align_v: hmUI.align.CENTER_V,
					 text_style: hmUI.text_style.NONE,
					 show_level: hmUI.show_level.ONLY_NORMAL,//| hmUI.show_level.ONLY_AOD
			});
		   }
		   
			bg_menu_01 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 253,
              src: 'bg_menu_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
           });
		   
		   bg_menu_01.setProperty(hmUI.prop.VISIBLE, false);
	   
		   for (let nn01 = 0; nn01 < 5; nn01++) {
			label_str_menu_01[nn01] = hmUI.createWidget(hmUI.widget.TEXT, {
					 x: 60,
					 y: 272+nn01*25,
					 w: 330,
					 h: 28,
					 text_size: 20,
					 //text: String(nn01+1),
					 text: 'День',
					 char_space: 0,
					 line_space: 0,
					 color: 0xFFFFFFFF,
					 align_h: hmUI.align.CENTER_H,
					 align_v: hmUI.align.CENTER_V,
					 text_style: hmUI.text_style.NONE,
					 show_level: hmUI.show_level.ONLY_NORMAL,
					 
			});
			label_str_menu_01[nn01].setProperty(hmUI.prop.VISIBLE, false);
		   }
		   */
            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
			  
			  let g_day = timeSensor.day;
			  let g_month = timeSensor.month;
			  let g_year = timeSensor.year;					  

              console.log('day of week font');
              if (updateHour) {
                //let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
				let normal_DOW_Str = formatNumber(g_day) + ' - ' + formatNumber(g_month) + ' - ' + formatNumber(g_year) + normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 168;
                  let start_y_normal_battery = 375;
                  let lenght_ls_normal_battery = 89;
                  let line_width_ls_normal_battery = 6;
                  let color_ls_normal_battery = 0xFF00E1FF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // normal_battery_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_battery_mirror = 168;
                  let start_y_normal_battery_mirror = 375;
                  let lenght_ls_normal_battery_mirror = -89;
                  let line_width_ls_normal_battery_mirror =6;
                  let color_ls_normal_battery_mirror = 0xFF00E1FF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw_mirror = start_x_normal_battery_mirror;
                  let start_y_normal_battery_draw_mirror = start_y_normal_battery_mirror;
                  lenght_ls_normal_battery_mirror = lenght_ls_normal_battery_mirror * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw_mirror = lenght_ls_normal_battery_mirror;
                  let line_width_ls_normal_battery_draw_mirror = line_width_ls_normal_battery_mirror;
                  if (lenght_ls_normal_battery_mirror < 0){
                    lenght_ls_normal_battery_draw_mirror = -lenght_ls_normal_battery_mirror;
                    start_x_normal_battery_draw_mirror = start_x_normal_battery - lenght_ls_normal_battery_draw_mirror;
                  };
                  
                  normal_battery_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw_mirror,
                    y: start_y_normal_battery_draw_mirror,
                    w: lenght_ls_normal_battery_draw_mirror,
                    h: line_width_ls_normal_battery_draw_mirror,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}