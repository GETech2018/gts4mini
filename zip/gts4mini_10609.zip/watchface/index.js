﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 388,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 59,
              // center_y: 316,
              // start_angle: 330,
              // end_angle: 30,
              // radius: 51,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFF0E56FE,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 59,
              center_y: 316,
              start_angle: 330,
              end_angle: 30,
              radius: 49,
              line_width: 4,
              corner_flag: 0,
              color: 0xFF0E56FE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 308,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: 6,
              unit_sc: '0031.png',
              unit_tc: '0031.png',
              unit_en: '0031.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 277,
              // center_y: 316,
              // start_angle: 330,
              // end_angle: 30,
              // radius: 51,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 277,
              center_y: 316,
              start_angle: 330,
              end_angle: 30,
              radius: 49,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 308,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 168,
              // center_y: 316,
              // start_angle: 330,
              // end_angle: 30,
              // radius: 51,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 168,
              center_y: 316,
              start_angle: 330,
              end_angle: 30,
              radius: 49,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 308,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 61,
              y: 129,
              src: '0029.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 15,
              y: 128,
              src: '0027.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 97,
              src: '0032.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 60,
              y: 95,
              src: '0028.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 3,
              w: 161,
              h: 26,
              text_size: 23,
              char_space: 1,
              line_space: 0,
              color: 0xFF7D7DFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.WRAP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 68,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0041.png',
              unit_tc: '0041.png',
              unit_en: '0041.png',
              negative_image: '0033.png',
              invalid_image: '0025.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 40,
              y: 4,
              image_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 38,
              month_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 38,
              day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: '0026.png',
              day_unit_tc: '0026.png',
              day_unit_en: '0026.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 137,
              y: 32,
              week_en: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              week_tc: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              week_sc: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 118,
              am_y: 146,
              am_sc_path: '0042.png',
              am_en_path: '0042.png',
              pm_x: 118,
              pm_y: 146,
              pm_sc_path: '0043.png',
              pm_en_path: '0043.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 67,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: '0013.png',
              hour_unit_tc: '0013.png',
              hour_unit_en: '0013.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 67,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 289,
              second_startY: 146,
              second_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 134,
              src: '0029.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 134,
              src: '0027.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 72,
              y: 134,
              src: '0032.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 123,
              y: 134,
              src: '0028.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 215,
              month_startY: 5,
              month_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 157,
              day_startY: 5,
              day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: '0026.png',
              day_unit_tc: '0026.png',
              day_unit_en: '0026.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 0,
              week_en: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              week_tc: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              week_sc: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 14,
              am_y: 64,
              am_sc_path: '0042.png',
              am_en_path: '0042.png',
              pm_x: 14,
              pm_y: 64,
              pm_sc_path: '0043.png',
              pm_en_path: '0043.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 40,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: '0013.png',
              hour_unit_tc: '0013.png',
              hour_unit_en: '0013.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 283,
              second_startY: 64,
              second_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

           //music shortcut
            normal_img_music = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 177,
              w: 78,
              h: 78,
              src: '0030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_music.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'PhoneMusicCtrlScreen', native: true })
            });

           //World Time shortcut
            normal_img_worldtime = hmUI.createWidget(hmUI.widget.IMG, {
              x: 118,
              y: 66,
              w: 215,
              h: 78,
              src: '0030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_worldtime.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'WorldClockScreen', native: true })
            });

           //Calendar shortcut
            normal_img_calendar = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 0,
              w: 176,
              h: 62,
              src: '0030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_calendar.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });

           //Alexa shortcut
            normal_img_alexa = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 177,
              w: 78,
              h: 78,
              src: '0030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_alexa.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'OnlineVADScreen', native: true })
            });

           //Compass shortcut
            normal_img_compass = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 177,
              w: 78,
              h: 78,
              src: '0030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_compass.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'CompassScreen', native: true })
            });

           //Find Phone shortcut
            normal_img_findphone = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 177,
              w: 78,
              h: 78,
              src: '0030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_findphone.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'FindPhoneScreen', native: true })
            });

           //Battery Manager shortcut
            normal_img_batterymanager = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 271,
              w: 96,
              h: 101,
              src: '0030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_batterymanager.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'Settings_batteryManagerScreen', native: true })
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 94,
              w: 95,
              h: 77,
              src: '0030.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 0,
              w: 104,
              h: 91,
              src: '0030.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 227,
              y: 271,
              w: 95,
              h: 101,
              src: '0030.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 271,
              w: 95,
              h: 101,
              src: '0030.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 59,
                      center_y: 316,
                      start_angle: 330,
                      end_angle: 30,
                      radius: 49,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFF0E56FE,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 277,
                      center_y: 316,
                      start_angle: 330,
                      end_angle: 30,
                      radius: 49,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 168,
                      center_y: 316,
                      start_angle: 330,
                      end_angle: 30,
                      radius: 49,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF00FF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}