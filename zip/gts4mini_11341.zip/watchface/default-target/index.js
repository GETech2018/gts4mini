try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_b48356d334de4dbab87160dfa28d8ff6 = '';
        let normal$_$text_8c5daf00a46242e9a49265e2918f948d = '';
        let normal$_$text_070da63c23ce4603a1f4eaa377a49185 = '';
        let normal$_$text_c72edc1dfee6469fb76eb3f03f275c76 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_6e0a01c7d93c4194b1b95a32c22787c8 = '';
        let stepSensor = '';
        let calorieSensor = '';
        let heartSensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '4.png'
                        },
                        {
                            'id': 2,
                            'path': '5.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 3,
                            'path': '6.png',
                            'preview': '6.png'
                        },
                        {
                            'id': 4,
                            'path': '7.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 5,
                            'path': '8.png',
                            'preview': '8.png'
                        },
                        {
                            'id': 6,
                            'path': '9.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 7,
                            'path': '10.png',
                            'preview': '10.png'
                        },
                        {
                            'id': 8,
                            'path': '11.png',
                            'preview': '11.png'
                        }
                    ],
                    count: 8,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                normal$_$text_b48356d334de4dbab87160dfa28d8ff6 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 93,
                    y: 347,
                    w: 150,
                    h: 25,
                    text: '[SC] steps',
                    color: '0xFFbfbfbf',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_8c5daf00a46242e9a49265e2918f948d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 93,
                    y: 322,
                    w: 150,
                    h: 25,
                    text: '[CAL] kcal',
                    color: '0xFF808080',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_070da63c23ce4603a1f4eaa377a49185 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 108,
                    y: 297,
                    w: 120,
                    h: 25,
                    text: '[HR] bpm',
                    color: '0xFFbfbfbf',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_c72edc1dfee6469fb76eb3f03f275c76 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 85,
                    y: 39,
                    w: 165,
                    h: 35,
                    text: '[DAY_Z].[MON_Z].[YEAR]',
                    color: '0xFFbfbfbf',
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_6e0a01c7d93c4194b1b95a32c22787c8 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 93,
                    y: 11,
                    w: 150,
                    h: 25,
                    text: '[WEEK_EN_F]',
                    color: '0xFF808080',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '12.png',
                    center_x: 0,
                    center_y: 192,
                    x: 3,
                    y: 64,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 180,
                    end_angle: 0,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 0,
                    hour_centerY: 192,
                    hour_posX: 150,
                    hour_posY: 150,
                    hour_path: '13.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 336,
                    minute_centerY: 192,
                    minute_posX: 150,
                    minute_posY: 150,
                    minute_path: '14.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 336,
                    second_centerY: 192,
                    second_posX: 150,
                    second_posY: 150,
                    second_path: '15.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_b48356d334de4dbab87160dfa28d8ff6.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_8c5daf00a46242e9a49265e2918f948d.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current } kcal` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_070da63c23ce4603a1f4eaa377a49185.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last } bpm` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_c72edc1dfee6469fb76eb3f03f275c76.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_c72edc1dfee6469fb76eb3f03f275c76.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_c72edc1dfee6469fb76eb3f03f275c76.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }.${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_6e0a01c7d93c4194b1b95a32c22787c8.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_b48356d334de4dbab87160dfa28d8ff6.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps` });
                        normal$_$text_8c5daf00a46242e9a49265e2918f948d.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current } kcal` });
                        normal$_$text_070da63c23ce4603a1f4eaa377a49185.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last } bpm` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_c72edc1dfee6469fb76eb3f03f275c76.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_c72edc1dfee6469fb76eb3f03f275c76.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_c72edc1dfee6469fb76eb3f03f275c76.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }.${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_6e0a01c7d93c4194b1b95a32c22787c8.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}