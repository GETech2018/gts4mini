﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_target_text_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_target_text_img = ''
        let idle_step_current_text_img = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg-06.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 42,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Asset_130.png',
              unit_tc: 'Asset_130.png',
              unit_en: 'Asset_130.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 34,
              src: 'Asset_125.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 42,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 146,
              year_startY: 287,
              year_sc_array: ["Asset_112.png","Asset_113.png","Asset_114.png","Asset_115.png","Asset_116.png","Asset_117.png","Asset_118.png","Asset_119.png","Asset_120.png","Asset_121.png"],
              year_tc_array: ["Asset_112.png","Asset_113.png","Asset_114.png","Asset_115.png","Asset_116.png","Asset_117.png","Asset_118.png","Asset_119.png","Asset_120.png","Asset_121.png"],
              year_en_array: ["Asset_112.png","Asset_113.png","Asset_114.png","Asset_115.png","Asset_116.png","Asset_117.png","Asset_118.png","Asset_119.png","Asset_120.png","Asset_121.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 83,
              month_startY: 287,
              month_sc_array: ["Asset_53.png","Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png"],
              month_tc_array: ["Asset_53.png","Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png"],
              month_en_array: ["Asset_53.png","Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 43,
              day_startY: 287,
              day_sc_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              day_tc_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              day_en_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 24,
              y: 34,
              src: 'Asset_137.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 34,
              src: 'Asset_126.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'jarum_batt.png',
              center_x: 253,
              center_y: 324,
              x: 8,
              y: 66,
              start_angle: -35,
              end_angle: 34,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 42,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'jarum_steps.png',
              center_x: 196,
              center_y: 371,
              x: 8,
              y: 260,
              start_angle: -40,
              end_angle: 0,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 104,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 262,
              font_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'fg-05.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 76,
              y: 236,
              week_en: ["Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png","Asset_77.png","Asset_78.png"],
              week_tc: ["Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png","Asset_77.png","Asset_78.png"],
              week_sc: ["Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png","Asset_77.png","Asset_78.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 24,
              am_y: 34,
              am_sc_path: 'Asset_127.png',
              am_en_path: 'Asset_127.png',
              pm_x: 24,
              pm_y: 34,
              pm_sc_path: 'Asset_128.png',
              pm_en_path: 'Asset_128.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 177,
              hour_array: ["Asset_41.png","Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png","Asset_46.png","Asset_47.png","Asset_48.png","Asset_49.png","Asset_50.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_unit_sc: 'Asset_51.png',
              hour_unit_tc: 'Asset_51.png',
              hour_unit_en: 'Asset_51.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 213,
              minute_startY: 181,
              minute_array: ["Asset_41.png","Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png","Asset_46.png","Asset_47.png","Asset_48.png","Asset_49.png","Asset_50.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg-07.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 42,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Asset_130.png',
              unit_tc: 'Asset_130.png',
              unit_en: 'Asset_130.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 42,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 146,
              year_startY: 287,
              year_sc_array: ["Asset_112.png","Asset_113.png","Asset_114.png","Asset_115.png","Asset_116.png","Asset_117.png","Asset_118.png","Asset_119.png","Asset_120.png","Asset_121.png"],
              year_tc_array: ["Asset_112.png","Asset_113.png","Asset_114.png","Asset_115.png","Asset_116.png","Asset_117.png","Asset_118.png","Asset_119.png","Asset_120.png","Asset_121.png"],
              year_en_array: ["Asset_112.png","Asset_113.png","Asset_114.png","Asset_115.png","Asset_116.png","Asset_117.png","Asset_118.png","Asset_119.png","Asset_120.png","Asset_121.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 83,
              month_startY: 287,
              month_sc_array: ["Asset_53.png","Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png"],
              month_tc_array: ["Asset_53.png","Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png"],
              month_en_array: ["Asset_53.png","Asset_54.png","Asset_55.png","Asset_56.png","Asset_57.png","Asset_58.png","Asset_59.png","Asset_60.png","Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 43,
              day_startY: 287,
              day_sc_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              day_tc_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              day_en_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'jarum_batt.png',
              center_x: 253,
              center_y: 324,
              x: 8,
              y: 66,
              start_angle: -35,
              end_angle: 34,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 42,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'jarum_steps.png',
              center_x: 196,
              center_y: 371,
              x: 8,
              y: 260,
              start_angle: -40,
              end_angle: 0,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 104,
              font_array: ["Asset_13.png","Asset_14.png","Asset_15.png","Asset_16.png","Asset_17.png","Asset_18.png","Asset_19.png","Asset_20.png","Asset_21.png","Asset_22.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 262,
              font_array: ["Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_105.png","Asset_106.png","Asset_107.png","Asset_108.png","Asset_109.png","Asset_110.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'fg-08.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 76,
              y: 236,
              week_en: ["Asset_141.png","Asset_142.png","Asset_143.png","Asset_144.png","Asset_145.png","Asset_146.png","Asset_147.png"],
              week_tc: ["Asset_141.png","Asset_142.png","Asset_143.png","Asset_144.png","Asset_145.png","Asset_146.png","Asset_147.png"],
              week_sc: ["Asset_141.png","Asset_142.png","Asset_143.png","Asset_144.png","Asset_145.png","Asset_146.png","Asset_147.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 24,
              am_y: 34,
              am_sc_path: 'Asset_139.png',
              am_en_path: 'Asset_139.png',
              pm_x: 24,
              pm_y: 34,
              pm_sc_path: 'Asset_140.png',
              pm_en_path: 'Asset_140.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 177,
              hour_array: ["Asset_41.png","Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png","Asset_46.png","Asset_47.png","Asset_48.png","Asset_49.png","Asset_50.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_unit_sc: 'Asset_51.png',
              hour_unit_tc: 'Asset_51.png',
              hour_unit_en: 'Asset_51.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 213,
              minute_startY: 181,
              minute_array: ["Asset_41.png","Asset_42.png","Asset_43.png","Asset_44.png","Asset_45.png","Asset_46.png","Asset_47.png","Asset_48.png","Asset_49.png","Asset_50.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}