﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 30,
              year_startY: 50,
              year_sc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              year_tc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              year_en_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 337,
              week_en: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png"],
              week_tc: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png"],
              week_sc: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 30,
              month_startY: 300,
              month_sc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              month_tc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              month_en_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 0,
              // start_y: 10,
              // color: 0xFFCE0000,
              // lenght: 320,
              // line_width: 6,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 50,
              font_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 250,
              day_startY: 300,
              day_sc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              day_tc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              day_en_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '000.png',
              hour_centerX: 168,
              hour_centerY: 194,
              hour_posX: 29,
              hour_posY: 191,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '001.png',
              minute_centerX: 168,
              minute_centerY: 194,
              minute_posX: 29,
              minute_posY: 191,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '002.png',
              second_centerX: 168,
              second_centerY: 194,
              second_posX: 28,
              second_posY: 191,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 30,
              year_startY: 50,
              year_sc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              year_tc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              year_en_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 337,
              week_en: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png"],
              week_tc: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png"],
              week_sc: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 30,
              month_startY: 300,
              month_sc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              month_tc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              month_en_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 0,
              // start_y: 10,
              // color: 0xFFCE0000,
              // lenght: 320,
              // line_width: 6,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 50,
              font_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 250,
              day_startY: 300,
              day_sc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              day_tc_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              day_en_array: ["132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '000.png',
              hour_centerX: 168,
              hour_centerY: 194,
              hour_posX: 29,
              hour_posY: 191,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '001.png',
              minute_centerX: 168,
              minute_centerY: 194,
              minute_posX: 29,
              minute_posY: 191,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 0;
                  let start_y_normal_battery = 10;
                  let lenght_ls_normal_battery = 320;
                  let line_width_ls_normal_battery = 6;
                  let color_ls_normal_battery = 0xFFCE0000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 0;
                  let start_y_idle_battery = 10;
                  let lenght_ls_idle_battery = 320;
                  let line_width_ls_idle_battery = 6;
                  let color_ls_idle_battery = 0xFFCE0000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
