﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg-03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 175,
              day_startY: 277,
              day_sc_array: ["Asset_921b.png","Asset_922b.png","Asset_923b.png","Asset_924b.png","Asset_925b.png","Asset_926b.png","Asset_927b.png","Asset_928b.png","Asset_929b.png","Asset_930b.png"],
              day_tc_array: ["Asset_921b.png","Asset_922b.png","Asset_923b.png","Asset_924b.png","Asset_925b.png","Asset_926b.png","Asset_927b.png","Asset_928b.png","Asset_929b.png","Asset_930b.png"],
              day_en_array: ["Asset_921b.png","Asset_922b.png","Asset_923b.png","Asset_924b.png","Asset_925b.png","Asset_926b.png","Asset_927b.png","Asset_928b.png","Asset_929b.png","Asset_930b.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Asset_931b.png',
              day_unit_tc: 'Asset_931b.png',
              day_unit_en: 'Asset_931b.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 197,
              month_startY: 266,
              month_sc_array: ["Asset_97.png","Asset_98.png","Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_109.png","Asset_110.png","Asset_111.png","Asset_112.png"],
              month_tc_array: ["Asset_97.png","Asset_98.png","Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_109.png","Asset_110.png","Asset_111.png","Asset_112.png"],
              month_en_array: ["Asset_97.png","Asset_98.png","Asset_99.png","Asset_100.png","Asset_101.png","Asset_102.png","Asset_103.png","Asset_104.png","Asset_109.png","Asset_110.png","Asset_111.png","Asset_112.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 277,
              font_array: ["Asset_921b.png","Asset_922b.png","Asset_923b.png","Asset_924b.png","Asset_925b.png","Asset_926b.png","Asset_927b.png","Asset_928b.png","Asset_929b.png","Asset_930b.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 265,
              image_array: ["Asset_61.png","Asset_62.png","Asset_63.png","Asset_64.png","Asset_65.png","Asset_66.png","Asset_67.png","Asset_68.png","Asset_69.png","Asset_70.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 197,
              week_en: ["Asset_90.png","Asset_91.png","Asset_92.png","Asset_93.png","Asset_94.png","Asset_95.png","Asset_96.png"],
              week_tc: ["Asset_90.png","Asset_91.png","Asset_92.png","Asset_93.png","Asset_94.png","Asset_95.png","Asset_96.png"],
              week_sc: ["Asset_90.png","Asset_91.png","Asset_92.png","Asset_93.png","Asset_94.png","Asset_95.png","Asset_96.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 178,
              font_array: ["Asset_21a.png","Asset_22a.png","Asset_23a.png","Asset_24a.png","Asset_25a.png","Asset_26a.png","Asset_27a.png","Asset_28a.png","Asset_29a.png","Asset_30a.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Asset_85.png',
              unit_tc: 'Asset_85.png',
              unit_en: 'Asset_85.png',
              negative_image: 'Asset_31a.png',
              invalid_image: 'Asset_32a.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 206,
              font_array: ["Asset_21.png","Asset_22.png","Asset_23.png","Asset_24.png","Asset_25.png","Asset_26.png","Asset_27.png","Asset_28.png","Asset_29.png","Asset_30.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 168,
              font_array: ["Asset_21.png","Asset_22.png","Asset_23.png","Asset_24.png","Asset_25.png","Asset_26.png","Asset_27.png","Asset_28.png","Asset_29.png","Asset_30.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Asset_32.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 37,
              hour_array: ["Asset_1.png","Asset_2.png","Asset_3.png","Asset_4.png","Asset_5.png","Asset_6.png","Asset_7.png","Asset_8.png","Asset_9.png","Asset_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Asset_12.png',
              hour_unit_tc: 'Asset_12.png',
              hour_unit_en: 'Asset_12.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Asset_1.png","Asset_2.png","Asset_3.png","Asset_4.png","Asset_5.png","Asset_6.png","Asset_7.png","Asset_8.png","Asset_9.png","Asset_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg-05.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 122,
              hour_array: ["Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png","Asset_77.png","Asset_78.png","Asset_79.png","Asset_80.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Asset_82.png',
              hour_unit_tc: 'Asset_82.png',
              hour_unit_en: 'Asset_82.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Asset_71.png","Asset_72.png","Asset_73.png","Asset_74.png","Asset_75.png","Asset_76.png","Asset_77.png","Asset_78.png","Asset_79.png","Asset_80.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}