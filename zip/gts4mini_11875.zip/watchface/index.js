﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc=0;
let nLucaAnim=0;
let nMaxAnim=2

function click_LucaAnim(){
    nLucaAnim=nLucaAnim+1;
	if(nLucaAnim>nMaxAnim){nLucaAnim=0;}
    Show_LucaAnim();
}

//////////////////////////////////////////////////////////////////////////////////////////////////

// Animation ON
function Show_LucaAnim(){

  if(nLucaAnim==0){
	hmUI.showToast({text: 'Animation: OFF'});
    normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    false);
    normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE,    false);
	normal_background_bg_img.setProperty(hmUI.prop.SRC,    "bg-BTsfc.png");
  }

  if(nLucaAnim==1){
	hmUI.showToast({text: 'Swimming'});
	normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    true);
	normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE,    false);
	normal_background_bg_img.setProperty(hmUI.prop.SRC,    "bg-black.png");
  }
  if(nLucaAnim==2){
	hmUI.showToast({text: 'Riding'});
	normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    false);
	normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE,    true);
	normal_background_bg_img.setProperty(hmUI.prop.SRC,    "bg-black.png");
  }
}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 336,
              src: 'bg-BTsfc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 195,
              second_startY: 213,
              second_array: ["numg00.png","numg01.png","numg02.png","numg03.png","numg04.png","numg05.png","numg06.png","numg07.png","numg08.png","numg09.png"],
              second_zero: 1,
              second_space: -28,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 112,
              minute_startY: 213,
              minute_array: ["numr00.png","numr01.png","numr02.png","numr03.png","numr04.png","numr05.png","numr06.png","numr07.png","numr08.png","numr09.png"],
              minute_zero: 1,
              minute_space: -28,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 24,
              hour_startY: 213,
              hour_array: ["numo00.png","numo01.png","numo02.png","numo03.png","numo04.png","numo05.png","numo06.png","numo07.png","numo08.png","numo09.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 53,
              y: 1,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "frame",
              anim_fps: 15,
              anim_size: 14,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 336,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 195,
              second_startY: 213,
              second_array: ["numg00.png","numg01.png","numg02.png","numg03.png","numg04.png","numg05.png","numg06.png","numg07.png","numg08.png","numg09.png"],
              second_zero: 1,
              second_space: -28,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 112,
              minute_startY: 213,
              minute_array: ["numr00.png","numr01.png","numr02.png","numr03.png","numr04.png","numr05.png","numr06.png","numr07.png","numr08.png","numr09.png"],
              minute_zero: 1,
              minute_space: -28,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 24,
              hour_startY: 213,
              hour_array: ["numo00.png","numo01.png","numo02.png","numo03.png","numo04.png","numo05.png","numo06.png","numo07.png","numo08.png","numo09.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 70,
              w: 210,
              h: 210,
              text: '',
              color: 0xFFFF8C00,
              text_size: 17,
              press_src: 'numblank.png',
              normal_src: 'numblank.png',
              click_func: (button_widget) => {
                click_LucaAnim();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc==0 ){
nLucaAnim=0;
Show_LucaAnim();
hmUI.showToast({text: 'Init'});
cc =1;
}
// a 'körbeírt' szövegek automatikus megjelenítését meg kell akadályozni, 
// hogy csak a saját fázisukban jelenjenek meg...
// if (screenType != hmSetting.screen_type.AOD && nLucaAnim==0)
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}