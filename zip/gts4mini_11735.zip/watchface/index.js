﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start
        
        let normal_background_bg_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_image_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс', ];
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = [' [ПН]', ' [ВТ]', ' [СР]', ' [ЧТ]', ' [ПТ]', ' [СБ]', ' [ВС]', ];
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('user_script_start.js');
            // start user_script_start.js

const red_dayRU_array = [
[ 1,  1, 'Новый Год!'],
[ 2,  1, 'Новогодние каникулы'],
[ 3,  1, 'Новогодние каникулы'],
[ 4,  1, 'Новогодние каникулы'],
[ 5,  1, 'Новогодние каникулы'],
[ 6,  1, 'Новогодние каникулы'],
[ 7,  1, 'Рождество Христово'],
[23,  2, 'День защитника Отечества'],
[ 8,  3, 'Международный женский день'],
[ 1,  5, 'Праздник Весны и Труда'],
[ 9,  5, 'День Победы'],
[12,  6, 'День России'],
[ 4, 11, 'День народного единства'],
];

const red_dayRU_array_HB = [
[15,  1, '1795 г. А.С. Грибоедов'],
[15,  1, '1891 г. Осип Мандельштам'],
[17,  1, '1863 г. Константин Станиславский'],
[25,  1, '1938 г. Владимир Высоцкий'],
[27,  1, '1826 г. М.Е. Салтыков-Щедрин'],
[29,  1, '1860 г. А.П. Чехов'],

[ 2,  2, '1904 г. Валерий Чкалов'],
[ 4,  2, '1831 г. Н.С. Лесков'],
[ 4,  2, '1906 г. А.Л. Барто'],
[ 8,  2, '1834 г. Дмитрий Менделеев'],
[10,  2, '1890 г. Б.Л. Пастернак'],
[13,  2, '1769 г. И.А. Крылов'],
[16,  2, '1831 г. Николай Лесков'],
[17,  2, '1906 г. Агния Барто'],

[ 6,  3, '1937 г. Валентина Терешкова'],
[ 7,  3, '1941 г. Андрей Миронов'],
[ 9,  3, '1814 г. Тарас Шевченко'],
[ 9,  3, '1934 г. Юрий Гагарин'],
[13,  3, '1913 г. С.В. Михалков'],
[16,  3, '1859 г. Александр Попов'],
[16,  3, '1884 г. А.Р. Беляев'],
[21,  3, '1839 г. Модест Мусоргский'],
[28,  3, '1868 г. Максим Горький'],
[31,  3, '1882 г. К.И. Чуковский'],

[ 1,  4, '1809 г. Н.В. Гоголь'],
[15,  4, '1886 г. Н.С. Гумилёв'],
[15,  4, '1933 г. Б.Н. Стругацкий'],
[18,  4, '1917 г. Георгий Вицин'],
[22,  4, '1899 г. В.В. Набоков'],

[12,  5, '1933 г. А.А. Вознесенский'],
[15,  5, '1891 г. М.А. Булгаков'],
[24,  5, '1905 г. М.А. Шолохов'],
[24,  5, '1940 г. И.А. Бродский'],
[31,  5, '1892 г. К.Г. Паустовский'],

[ 6,  6, '1799 г. А.С. Пушкин'],
[ 9,  6, '1672 г. Петр Первый'],
[18,  6, '1812 г. И.А. Гончаров'],
[21,  6, '1962 г. Виктор Цой'],
[23,  6, '1889 г. А.А. Ахматова'],

[18,  7, '1932 г. Е.А. Евтушенко'],
[19,  7, '1893 г. В.В. Маяковский'],

[10,  8, '1895 г. М.М. Зощенко'],
[28,  8, '1925 г. А.Н. Стругацкий'],
[31,  8, '1749 г. А.Н. Радищев'],

[ 3,  9, '1941 г. С.Д. Довлатов'],
[ 7,  9, '1817 г. А.К. Куприн'],
[ 9,  9, '1828 г. Л.Н. Толстой'],
[29,  9, '1904 г. Н.А. Островский'],

[ 1, 10, '1912 г. Л.Н. Гумилёв'],
[ 3, 10, '1895 г. С.А. Есенин'],
[ 7, 10, '1952 г. Владимир Путин'],
[ 8, 10, '1892 г. М.А. Цветаева'],
[15, 10, '1814 г. М.Ю. Лермонтов'],
[18, 10, '1934 г. Кир Булычев'],
[22, 10, '1870 г. И.А. Бунин'],

[ 3, 11, '1887 г. С.Я. Маршак'],
[11, 11, '1821 г. Ф.М. Достоевский'],
[19, 11, '1711 г. М.В. Ломоносов'],
[22, 11, '1801 г. В.И. Даль'],
[23, 11, '1908 г. Н.Н. Носов'],
[28, 11, '1880 г. А.А. Блок'],

[ 5, 12, '1803 г. Ф.И. Тютчев'],
[10, 12, '1821 г. Н.А. Некрасов'],
[11, 12, '1918 г. А.И. Солженицын'],
[12, 12, '1766 г. Н.М. Карамзин'],
[18, 12, '1921 г. Юрий Никулин'],
[27, 12, '1971 г. Сергей Бодров мл.'],
];

const red_dayRU_array_ALL = [
[14,  1, 'Старый Новый год'],
[19,  1, 'Крещение Господне'],
[25,  1, 'Татьянин день'],
[27,  1, 'День снятия блокады Ленинграда'],
[14,  2, 'День влюбленных'],
[ 3,  3, 'Всемирный день писателя'],
[18,  3, 'День воссоединения Крыма и России'],
[ 1,  4, 'День смеха'],
[12,  4, 'День космонавтики'],
[26,  4, '1986 г. авария на Чернобыльской АЭС'],
[27,  5, 'День библиотек'],
[ 1,  6, 'День защиты детей'],
[22,  6, 'День начала ВОВ (1941 год)'],
[ 7,  7, 'Иван Купала'],
[ 8,  7, 'День семьи, любви и верности'],
[28,  7, 'День крещения Руси'],
[ 2,  8, 'День ВДВ'],
[ 1,  9, 'День знаний'],
[ 5, 10, 'День учителя'],
];

let label_TXT = '...';
let label_TXT_menu = '';
let label_SELECT = 0;

let MENU_MODE = 1;
let MENU_MODE_limit = 2;
let MENU_pos_start = 0;
let MENU_pos_RESET = 0;
let MENU_pos_ALL = 0;

const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)

const RED_DAY_OFFICIAL	= 0b00000001; //официальный выходной в РФ
const RED_DAY_HB 		= 0b00000010; //день рождения
const RED_DAY_ALL 		= 0b00000100; //другое событие
const RED_DAY_SELECT	= 0b10000000; //текущий день

//смещение адресов, по диапазону которых можно понять на какой из архивов ссылка
const OFFSET_OFFICIAL	= 0;
const OFFSET_HB 		= 500; 	//надеюсь официальных праздников будет не более))
const OFFSET_ALL 		= 5000;	//вряд ли друзей больше... если что, пиши поправлю код (но это не точно)

let stopVibro_Timer = null;
let new_Timer = null;
let old_day = 63;
let old_month = 63;
let old_year = 1979;
let bg_index = 0;
let viewRD = false;		  //есть сегодня праздник
let t_counter_01 = 0;	  //счетчик таймера 1 (срабатывает с периодичностью 1000 мс)
let t_counter_02 = 0;	  //счетчик таймера переключений label_TXT
let t_counter_03 = 0;	  //счетчик таймера, обнуляется каждый раз в момент пробуждения экрана
let limit_counter_02 = 2; //частота переключений label_TXT в секундах
let limit_counter_03 = 60;//как долго отображать уведомления в label_TXT о событиях
let g_counter_01 = 0;	  //счетчик 01 [нажатия на календарь]
let g_counter_02 = 0;	  //счетчик 02 [число обновлений клаендаря]
let label_days = [];
let label_str_menu_01 = [];
let label_str_limit = 8;
let bg_day_img = '';
let bg_menu_01 = '';
let month_day_nums = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
let month_name = ['...', 'ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ', 'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ'];
let color_LABEL = [0xFF80C8F5, 0xFF00D8F8, 0xFFF8EF00, 0xFF00F85D, 0xFFD726C4, 0xFFFFFFFF];
let color_MENU = 	 	 [0xFFFFFFFF, 0xFF909090];
const color_CALENDAR = [
[0xFFFFFFFF, 0xFF000000, 0xFFFF3030, 0xFF80C8F5, 0xFFE9E9E9, 0xFF808080, 0xFFDD5050],
[0xFFB9B9B9, 0xFF000000, 0xFFF02020, 0xFFFFD8A6, 0xFFE9E9E9, 0xFF808080, 0xFFDD5050],
[0xFFB9B9B9, 0xFF000000, 0xFFF02020, 0xFFDD5050, 0xFFDD5050, 0xFF969696, 0xFFF02020],
[0xFFB9B9B9, 0xFF000000, 0xFFF02020, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF969696, 0xFFF02020],
[0xFF999999, 0xFF000000, 0xFF800000, 0xFF805E33, 0xFF666666, 0xFF404040, 0xFF702020],
]

let cCs = 0; //color_CALENDAR_select


//31 запись
//red_dayRU_array_cache[nn01][0] = 0;				//тип праздничного дня (официальный, день рождения, другое)
//red_dayRU_array_cache[nn01][1] = x;				//координата X
//colorDay_cache[nn01][2] = y;				//координата Y
//red_dayRU_array_cache[nn01][3] = 1,2,3,4,5,6,7;	//день недели

let red_dayRU_array_cache = [
[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],
[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],
[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],
[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],
[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0],
];


//31 запись
//тут храним ссылку на порядковый номер в массивах с праздником, по след правилам:
//red_dayRU_array_cache2[nn01][0] = 0;	//количество праздников в этот день (для простоты записи, и чтобы не обнулять архив каждый месяц)
//red_dayRU_array_cache2[nn01][1..10];	//ссылка на праздник в массивах

let red_dayRU_array_cache2 = [
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
];

const bg_list = [
'bg_01.png',
'bg_02.png',
];

const ico_alarm_list = [
'icon_alarm_1.png',
'icon_alarm_2.png',
'icon_alarm_3.png',
'icon_alarm_4.png',
'icon_alarm_5.png',
'icon_alarm_6.png',
];

//============================================================ COLORS =

function colors_update() {
	
	normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
	normal_system_clock_img.setProperty(hmUI.prop.SRC, ico_alarm_list[bg_index]);
	
	let colorDay = color_LABEL[bg_index];
	normal_dow_text_font.setProperty(hmUI.prop.COLOR, colorDay);
	normal_city_name_text.setProperty(hmUI.prop.COLOR, colorDay);
}

//========================================================== CALENDAR =

function UpdateCalendar(c_day, c_month, c_year) {
	
	let need_update = false;
	//c_day = 23;  c_month = 9;  c_year = 2024;//test
	if ((c_day == 0) || (c_month == 0) || (c_year == 0)) { c_day = 13;  c_month = 2;  c_year = 2024; } // защита от бага эмулятора
	if ((c_month != old_month) || (c_year != old_year)) need_update = true;
	
	if (need_update) {
		
		g_counter_02++;
		getLeapYear(c_year);
                
		let tmp_week = getWeekdayNUM(1, c_month, c_year); //с какого дня недели начинается месяц
				
		//очищаем массивы с кэшем праздничных дней
		//let red_dayRU_array_cache = new Array(31).fill().map(() => new Array(2));
		for (let nn01 = 0; nn01 < 31; nn01++) {
			red_dayRU_array_cache[nn01][0] = 0;
			red_dayRU_array_cache2[nn01][0] = 0;
		}
		

		// собственно кэшируем, первыми официальные праздники
		for (let nn01 = 0; nn01 < red_dayRU_array.length; nn01++) {
				   
			if (c_month == red_dayRU_array[nn01][1] ) {
				
				let RedDay = red_dayRU_array[nn01][0]-1;
				red_dayRU_array_cache[RedDay][0] = red_dayRU_array_cache[RedDay][0] | RED_DAY_OFFICIAL;
				
				//сохраняем адрес
				red_dayRU_array_cache2[RedDay][0]++;
				red_dayRU_array_cache2[RedDay][1] = OFFSET_OFFICIAL + nn01; //официальные праздники можно всегда писать в 1 ячейку,
																			//но в идеале нужно "1" поменять на red_dayRU_array_cache2[RedDay][0]
			}
		}
		
	
		// теперь кэшируем, дни рождения
		for (let nn01 = 0; nn01 < red_dayRU_array_HB.length; nn01++) {
				   
			if (c_month == red_dayRU_array_HB[nn01][1] ) {
				
				let RedDay = red_dayRU_array_HB[nn01][0]-1;
				red_dayRU_array_cache[RedDay][0] = red_dayRU_array_cache[RedDay][0] | RED_DAY_HB;
				
				//сохраняем адрес
				red_dayRU_array_cache2[RedDay][0]++;
				red_dayRU_array_cache2[RedDay][red_dayRU_array_cache2[RedDay][0]] = OFFSET_HB + nn01;
			}
		}

		// и наконец кэшируем, все остальные памятные дни
		for (let nn01 = 0; nn01 < red_dayRU_array_ALL.length; nn01++) {
				   
			if (c_month == red_dayRU_array_ALL[nn01][1] ) {
				
				let RedDay = red_dayRU_array_ALL[nn01][0]-1;
				red_dayRU_array_cache[RedDay][0] = red_dayRU_array_cache[RedDay][0] | RED_DAY_ALL;
				
				//сохраняем адрес
				red_dayRU_array_cache2[RedDay][0]++;
				red_dayRU_array_cache2[RedDay][red_dayRU_array_cache2[RedDay][0]] = OFFSET_ALL + nn01;
			}
		}

		let sx=0;
		let sy=210;
		let new_x=0;
		//let delta_y = tmp_week < 6 ? 25 : 20;
		let delta_y = (tmp_week < (6 + 31-month_day_nums[c_month])) ? 25 : 20;
		

		for (let nn01 = 0; nn01 < month_day_nums[c_month]; nn01++) {
			
			new_x = tmp_week * 39;
			red_dayRU_array_cache[nn01][1] = sx + new_x;
			red_dayRU_array_cache[nn01][2] = sy;
			red_dayRU_array_cache[nn01][3] = tmp_week;
			tmp_week++;

			if (tmp_week > 7) {
				tmp_week = 1;
				sy += delta_y;
			}

		}
		
		old_day=c_day;
		old_month=c_month;
		old_year=c_year;
		
		DrawCalendar(c_day, c_month, c_year);
	} else {
		if ( c_day != old_day ) {
			old_day=c_day;
			DrawCalendar(c_day, c_month, c_year);
		}
	}
}

function DrawCalendar(c_day, c_month, c_year) {
	// отрисовка календаря
	// включаем отображение 29-30-31 чисел месяца
	//label_days[28].setProperty(hmUI.prop.VISIBLE, true);
	//label_days[29].setProperty(hmUI.prop.VISIBLE, true);
	//label_days[30].setProperty(hmUI.prop.VISIBLE, true);
	
	let typeRD = 0; 
	MENU_pos_ALL = 0;
	MENU_pos_RESET = 0;	
	
	for (let nn01 = 0; nn01 < month_day_nums[c_month]; nn01++) {
		
		typeRD = red_dayRU_array_cache[nn01][0];

		if (nn01+1 == c_day) { typeRD = typeRD | RED_DAY_SELECT }
		
		let colorDay = (typeRD & RED_DAY_OFFICIAL) ? ((typeRD & RED_DAY_SELECT) ? color_CALENDAR[cCs][0] : color_CALENDAR[cCs][2]) : (typeRD & RED_DAY_HB) ? ((typeRD & RED_DAY_SELECT) ? color_CALENDAR[cCs][1] : color_CALENDAR[cCs][3]) : (typeRD & RED_DAY_ALL) ? ((typeRD & RED_DAY_SELECT) ? color_CALENDAR[cCs][1] : color_CALENDAR[cCs][4]) : ((red_dayRU_array_cache[nn01][3] < 6) ? ((typeRD & RED_DAY_SELECT) ? color_CALENDAR[cCs][1] : color_CALENDAR[cCs][5]) : ((typeRD & RED_DAY_SELECT) ? color_CALENDAR[cCs][1] : color_CALENDAR[cCs][6]));
		

		label_days[nn01].setProperty(hmUI.prop.MORE, {
			x: red_dayRU_array_cache[nn01][1],
			y: red_dayRU_array_cache[nn01][2],
			//w: 30,
			//h: 30,
			//text_size: 16,
			//text: String(nn01+1),
			//char_space: 0,
			//line_space: 0,
			color: colorDay,
			//align_h: hmUI.align.CENTER_H,
			//align_v: hmUI.align.CENTER_V,
			//text_style: hmUI.text_style.NONE,
			//show_level: hmUI.show_level.ONLY_NORMAL,
		});

		if (typeRD & RED_DAY_SELECT) {
			bg_day_img.setProperty(hmUI.prop.MORE, {
			x: red_dayRU_array_cache[nn01][1] - 2,
			y: red_dayRU_array_cache[nn01][2] + 3,
			
			src: (typeRD & RED_DAY_OFFICIAL) ? 'bg_day_1.png' : (typeRD & RED_DAY_HB) ? 'bg_day_2.png' : (typeRD & RED_DAY_ALL) ? 'bg_day_4.png' : 
			(red_dayRU_array_cache[nn01][3] > 5) ? 'bg_day_1.png' : 'bg_day_128.png',
			});
		}
		
		let count_RedDay = red_dayRU_array_cache2[nn01][0];
		if (count_RedDay>0) {
			if ((nn01+1) <= c_day) MENU_pos_RESET = MENU_pos_ALL;
			MENU_pos_ALL += count_RedDay+1;
		}		
		
	}
	
	MENU_pos_start = MENU_pos_RESET;

	//выключаем отображение дней если месяц короче 31 дня
	//for (let nn01 = month_day_nums[c_month]; nn01 < 31; nn01++) {
	//	label_days[nn01].setProperty(hmUI.prop.VISIBLE, false);
	//}
	

	let colorDay = color_LABEL[bg_index];
	
	if (red_dayRU_array_cache[c_day-1][0] > 0) {

		label_TXT = formatNumber(c_day) + ' - ' + formatNumber(c_month) + ' - ' + formatNumber(c_year) + ' (' + month_name[c_month] + ') x';
		label_TXT += String( red_dayRU_array_cache2[c_day-1][0] ); //+кол-во праздников в этот день

	} else {

		label_TXT = formatNumber(c_day) + ' - ' + formatNumber(c_month) + ' - ' + formatNumber(c_year) + ' (' + month_name[c_month] + ')';
		//colorDay = 0xFF707070;
	}

	normal_dow_text_font.setProperty(hmUI.prop.COLOR, colorDay );
	normal_dow_text_font.setProperty(hmUI.prop.TEXT, label_TXT );

}


//====================================================== END CALENDAR =

function getWeekdayNUM(day, month, year) {
	const days = [7, 1, 2, 3, 4, 5, 6];
	let date = new Date(year, month-1, day);
	return days[date.getDay()];
}

function getWeekday(day, month, year) {
	const days = ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];
	let date = new Date(year, month-1, day);
	return days[date.getDay()];
}

function getMonth(month) {
	const months = ['ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ', 'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ'];
	return months[month-1];
}

function getMonth2(month) {
	const months = ['ЯНВАРЕ', 'ФЕВРАЛЕ', 'МАРТЕ', 'АПРЕЛЕ', 'МАЕ', 'ИЮНЕ', 'ИЮЛЕ', 'АВГУСТЕ', 'СЕНТЯБРЕ', 'ОКТЯБРЕ', 'НОЯБРЕ', 'ДЕКАБРЕ'];
	return months[month-1];
}


function getLeapYear(year) {
	let leap = false;
	if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {
	 month_day_nums[2] = 29;
	 leap = true;
	} else {
	 month_day_nums[2] = 28;
	 leap = false;
	}
	return leap;
}

function formatNumber(num) {
	return num < 10 ? '0' + num : num.toString();
}

//============================================================ TIMER =

function new_timer_update() {
	t_counter_01++;
	t_counter_02++;
	
	if ( (t_counter_01 % 2 == 0)&&((t_counter_01 < t_counter_03 + limit_counter_03)) ) { label_switching(); }
	
	//if ( (t_counter_00 > 240) && (MENU_MODE == 1) ) MUNU_SWITCH();
	
	normal_image_img.setProperty(hmUI.prop.VISIBLE, (t_counter_01 % 2 == 0));
}


//читаем из наших массивов, зная порядковый номер праздника и адрес смещения каждого из массивов
function get_RedDay(index) {
	

	if (index>=OFFSET_ALL) {
		return red_dayRU_array_ALL[index-OFFSET_ALL][2];
	} else if (index>=OFFSET_HB) {
		return red_dayRU_array_HB[index-OFFSET_HB][2];
	} else
		return red_dayRU_array[index-OFFSET_OFFICIAL][2];
	
}

function label_switching() {
	
	
	let count_RedDay = red_dayRU_array_cache2[old_day-1][0];
	
	if (count_RedDay>0)
	{
	
		label_SELECT++;
		if (label_SELECT > count_RedDay) { label_SELECT = 0; }
		
		if (label_SELECT == 0) {
			//tmp_string = label_TXT;
			normal_dow_text_font.setProperty(hmUI.prop.TEXT, label_TXT);
			
		} else {
			normal_dow_text_font.setProperty(hmUI.prop.TEXT, get_RedDay(red_dayRU_array_cache2[old_day-1][label_SELECT]));

		}
		
	}
}


function calendar_VISIBLE(visible_calendar) {

	let len_month = visible_calendar ? month_day_nums[old_month] : 31;
	for (let nn01 = 0; nn01 < len_month; nn01++) {
		label_days[nn01].setProperty(hmUI.prop.VISIBLE, visible_calendar);
	}
	
	bg_day_img.setProperty(hmUI.prop.VISIBLE, visible_calendar);

}

function DrawMenuLabels() {
	
	let pos_string = 0;
	let pos_start = MENU_pos_start;
	let count_RedDayALL = 0;
	
	for (let nn_days = 0; ((nn_days < month_day_nums[old_month]) && (pos_string<label_str_limit)); nn_days++) {
		
		let count_RedDay = red_dayRU_array_cache2[nn_days][0];
		if (count_RedDay>0) {
			
			if (count_RedDayALL+count_RedDay>=pos_start)
			{
				//заголовок ::: 4-01-2024 :::
				
				if (count_RedDayALL >= pos_start) {
					let temp_TXT = ': : :  '+formatNumber(nn_days+1) + ' - ' + formatNumber(old_month) + ' - ' + formatNumber(old_year)+'  : : :';
					label_str_menu_01[pos_string].setProperty(hmUI.prop.TEXT, temp_TXT);
					label_str_menu_01[pos_string].setProperty(hmUI.prop.COLOR, color_LABEL[bg_index] );
					pos_string++;
				}
				
				count_RedDayALL++;
			
				for (let nn01 = 1; ((nn01 <= count_RedDay) && (pos_string<label_str_limit)); nn01++) {
					
					//данные календаря >>> ABC <<<
					
					if (count_RedDayALL >= pos_start) {
						let temp_TXT = get_RedDay(red_dayRU_array_cache2[nn_days][nn01]);
						label_str_menu_01[pos_string].setProperty(hmUI.prop.TEXT, temp_TXT);
						label_str_menu_01[pos_string].setProperty(hmUI.prop.COLOR, color_MENU[0] );
						pos_string++;
					}
					count_RedDayALL++;
				}
			} else {
				count_RedDayALL += count_RedDay+1;
			}
			
		
		}
		
	}
	
	for (let nn01 = pos_string; (nn01 < label_str_limit); nn01++) {
		let temp_TXT = ': : : ------- : : :'
		label_str_menu_01[nn01].setProperty(hmUI.prop.TEXT, temp_TXT);
		label_str_menu_01[nn01].setProperty(hmUI.prop.COLOR, color_MENU[1] );
	}
}



//============================================================== KEY =

function bg_switching() {
    bg_index++;
    if (bg_index >= bg_list.length) bg_index = 0;

	//vibro();
	colors_update();
}


function MUNU_SWITCH() {
	
	MENU_MODE++;
	if (MENU_MODE > MENU_MODE_limit) MENU_MODE = 0;
	
	normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[MENU_MODE==2 ? 1 : 0]);

	// === 0 ====
	calendar_VISIBLE(MENU_MODE == 0);


	// === 1 ====
	bg_menu_01.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 1);

	for (let nn01 = 0; nn01 < label_str_limit; nn01++) {
		label_str_menu_01[nn01].setProperty(hmUI.prop.VISIBLE, MENU_MODE == 1 );
	}

	// === 2 ====
	normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_system_dnd_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, MENU_MODE == 2);
	
	//normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, (MENU_MODE == 2) );
	//normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, (MENU_MODE == 2) );
	//normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, (MENU_MODE == 2) );
	
	if (MENU_MODE == 0) {
		
		//normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[0]);

		MENU_pos_start = MENU_pos_RESET;
		let str_01 = 'пн     вт     ср     чт     пт     сб     вс';
		label_TXT_menu.setProperty(hmUI.prop.TEXT, str_01 );
		label_TXT_menu.setProperty(hmUI.prop.VISIBLE, true);
		//calendar_VISIBLE(true);
	}
	else if (MENU_MODE == 1) {
		//normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[0]);
		//normal_system_clock_img.setProperty(hmUI.prop.SRC, ico_alarm_list[0]);
		let str_01 = 'События календаря в '+getMonth2(old_month);				
		label_TXT_menu.setProperty(hmUI.prop.TEXT, str_01 );
		label_TXT_menu.setProperty(hmUI.prop.VISIBLE, true);
		DrawMenuLabels();
	} else {
		calendar_VISIBLE(false);
		label_TXT_menu.setProperty(hmUI.prop.VISIBLE, false);
		//normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[1]);
		//normal_system_clock_img.setProperty(hmUI.prop.SRC, ico_alarm_list[1]);
	}
	
	
	//console.log('::: ok :::');
}

function button_l() {
	if (MENU_MODE == 0) {
		//vibro(15);
		if (cCs > 0) {
			cCs--;
			DrawCalendar(old_day, old_month, old_year);
		}
		
	} else if (MENU_MODE == 1) {
		if (MENU_pos_start > 0) {
			vibro();
			MENU_pos_start --;
			DrawMenuLabels();
		}
	}
}

function button_r() {
	

	if (MENU_MODE == 0) {
		//vibro(15);
		//MUNU_SWITCH();
		if (cCs < 4) {
			cCs++;
			DrawCalendar(old_day, old_month, old_year);
		}
		
		
		
	} else if (MENU_MODE == 1) {
		if (MENU_pos_start < MENU_pos_ALL) {
			vibro();
			MENU_pos_start ++;
			DrawMenuLabels();
		}
	}
	
}

function button_mid() {
	
	vibro();
	MUNU_SWITCH();

}

function vibro(scene = 25) {
	
	vibrate.stop();
	vibrate.scene = scene;
	
	let stopDelay = 25;
	if (scene < 23 || scene > 25) stopDelay = 1220;
	vibrate.start();
	stopVibro_Timer = timer.createTimer(10, stopDelay, stopVibro, {});
}

function stopVibro() {
	vibrate.stop();
	timer.stopTimer(stopVibro_Timer);
}
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 224,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dws0_div.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 224,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dws0_div.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 260,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 260,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dws0_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 300,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dws0_km.png',
              unit_tc: 'dws0_km.png',
              unit_en: 'dws0_km.png',
              imperial_unit_sc: 'dws0_ml.png',
              imperial_unit_tc: 'dws0_ml.png',
              imperial_unit_en: 'dws0_ml.png',
              dot_image: 'dws0_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 300,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 358,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 90,
              src: 'icon_sleep.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 118,
              src: 'icon_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 146,
              src: 'icon_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 40,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dws0_perc.png',
              unit_tc: 'dws0_perc.png',
              unit_en: 'dws0_perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 40,
              font_array: ["dws0_00.png","dws0_01.png","dws0_02.png","dws0_03.png","dws0_04.png","dws0_05.png","dws0_06.png","dws0_07.png","dws0_08.png","dws0_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dws0_C.png',
              unit_tc: 'dws0_C.png',
              unit_en: 'dws0_C.png',
              negative_image: 'dws0_minus.png',
              invalid_image: 'dws0_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 148,
              y: 28,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 336,
              h: 30,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFF80C8F5,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 82,
              src: 'db1_div.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 165,
              w: 306,
              h: 26,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF80C8F5,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 82,
              hour_array: ["db1_00.png","db1_01.png","db1_02.png","db1_03.png","db1_04.png","db1_05.png","db1_06.png","db1_07.png","db1_08.png","db1_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 82,
              minute_array: ["db1_00.png","db1_01.png","db1_02.png","db1_03.png","db1_04.png","db1_05.png","db1_06.png","db1_07.png","db1_08.png","db1_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 278,
              second_startY: 112,
              second_array: ["dm1_00.png","dm1_01.png","dm1_02.png","dm1_03.png","dm1_04.png","dm1_05.png","dm1_06.png","dm1_07.png","dm1_08.png","dm1_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bg_03.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 358,
              font_array: ["dgs0_00.png","dgs0_01.png","dgs0_02.png","dgs0_03.png","dgs0_04.png","dgs0_05.png","dgs0_06.png","dgs0_07.png","dgs0_08.png","dgs0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 224,
              font_array: ["dgs0_00.png","dgs0_01.png","dgs0_02.png","dgs0_03.png","dgs0_04.png","dgs0_05.png","dgs0_06.png","dgs0_07.png","dgs0_08.png","dgs0_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dgs0_div.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 224,
              font_array: ["dgs0_00.png","dgs0_01.png","dgs0_02.png","dgs0_03.png","dgs0_04.png","dgs0_05.png","dgs0_06.png","dgs0_07.png","dgs0_08.png","dgs0_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dgs0_div.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 260,
              font_array: ["dgs0_00.png","dgs0_01.png","dgs0_02.png","dgs0_03.png","dgs0_04.png","dgs0_05.png","dgs0_06.png","dgs0_07.png","dgs0_08.png","dgs0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 260,
              font_array: ["dgs0_00.png","dgs0_01.png","dgs0_02.png","dgs0_03.png","dgs0_04.png","dgs0_05.png","dgs0_06.png","dgs0_07.png","dgs0_08.png","dgs0_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dws0_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 300,
              font_array: ["dgs0_00.png","dgs0_01.png","dgs0_02.png","dgs0_03.png","dgs0_04.png","dgs0_05.png","dgs0_06.png","dgs0_07.png","dgs0_08.png","dgs0_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dgs0_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 300,
              font_array: ["dgs0_00.png","dgs0_01.png","dgs0_02.png","dgs0_03.png","dgs0_04.png","dgs0_05.png","dgs0_06.png","dgs0_07.png","dgs0_08.png","dgs0_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 82,
              src: 'db2_div.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 82,
              hour_array: ["db2_00.png","db2_01.png","db2_02.png","db2_03.png","db2_04.png","db2_05.png","db2_06.png","db2_07.png","db2_08.png","db2_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 82,
              minute_array: ["db2_00.png","db2_01.png","db2_02.png","db2_03.png","db2_04.png","db2_05.png","db2_06.png","db2_07.png","db2_08.png","db2_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
			
            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 165,
              w: 306,
              h: 26,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF324754,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });			



            console.log('user_script_end.js');
            // start user_script_end.js

			if (new_Timer == null) { new_Timer = timer.createTimer(50, 1000, new_timer_update, {}); }

		   bg_day_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_day_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL, // | hmUI.show_level.ONLY_AOD
           });

            label_TXT_menu = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 190,
              w: 306,
              h: 26,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFAAAAAA,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		   for (let nn01 = 0; nn01 < 31; nn01++) {
			label_days[nn01] = hmUI.createWidget(hmUI.widget.TEXT, {
					 x: 0,
					 y: 0,
					 w: 30,
					 h: 28,
					 text_size: 20,
					 text: String(nn01+1),
					 char_space: 0,
					 line_space: 0,
					 color: 0x00000000,
					 align_h: hmUI.align.CENTER_H,
					 align_v: hmUI.align.CENTER_V,
					 text_style: hmUI.text_style.NONE,
					 show_level: hmUI.show_level.ONLY_NORMAL,//| hmUI.show_level.ONLY_AOD
			});
		   }
		   
			bg_menu_01 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 230,
              src: 'bg_menu_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
           });

		   for (let nn01 = 0; nn01 < label_str_limit; nn01++) {
			label_str_menu_01[nn01] = hmUI.createWidget(hmUI.widget.TEXT, {
					 x: 3,
					 y: 216+20*nn01,
					 w: 330,
					 h: 22,
					 text_size: 17,
					 text: '',
					 char_space: 0,
					 line_space: 0,
					 color: 0xFFFFFFFF,
					 //align_h: hmUI.align.LEFT,
					 align_h: hmUI.align.CENTER_H,
					 align_v: hmUI.align.CENTER_V,
					 text_style: hmUI.text_style.NONE,
					 show_level: hmUI.show_level.ONLY_NORMAL,
					 
			});
		   }
		   
		   MUNU_SWITCH();
		   
            // end user_script_end.js
			
            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 102,
              y: 216,
              w: 133,
              h: 160,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: 'dummy.png',
              normal_src: 'dummy.png',
              click_func: (button_widget) => {
                button_mid();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 216,
              w: 100,
              h: 160,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: 'dummy.png',
              normal_src: 'dummy.png',
              click_func: (button_widget) => {
                button_r();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 216,
              w: 100,
              h: 160,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: 'dummy.png',
              normal_src: 'dummy.png',
              click_func: (button_widget) => {
                button_l();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button			

            let screenType = hmSetting.getScreenType();
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
			  
			  let g_day = timeSensor.day;
			  let g_month = timeSensor.month;
			  let g_year = timeSensor.year;			  

			  
              console.log('day of week font normal');
              if (updateHour) {
				UpdateCalendar(g_day, g_month, g_year);

              };

              if (updateHour) {
                let idle_DOW_Str = formatNumber(g_day) + ' - ' + formatNumber(g_month) + ' - ' + formatNumber(g_year) + idle_DOW_Array[timeSensor.week-1];
				idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };
            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				t_counter_03 = t_counter_01;
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}