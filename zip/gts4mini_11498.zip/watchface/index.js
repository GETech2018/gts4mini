﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 283,
              font_array: ["Frame_22.png","Frame_23.png","Frame_24.png","Frame_25.png","Frame_26.png","Frame_27.png","Frame_28.png","Frame_29.png","Frame_30.png","Frame_31.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Frame_32.png',
              unit_tc: 'Frame_32.png',
              unit_en: 'Frame_32.png',
              negative_image: 'Frame_44.png',
              invalid_image: 'Frame_44.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 140,
              month_startY: 115,
              month_sc_array: ["Frame_10.png","Frame_11.png","Frame_12.png","Frame_13.png","Frame_14.png","Frame_15.png","Frame_16.png","Frame_17.png","Frame_18.png","Frame_19.png","Frame_20.png","Frame_21.png"],
              month_tc_array: ["Frame_10.png","Frame_11.png","Frame_12.png","Frame_13.png","Frame_14.png","Frame_15.png","Frame_16.png","Frame_17.png","Frame_18.png","Frame_19.png","Frame_20.png","Frame_21.png"],
              month_en_array: ["Frame_10.png","Frame_11.png","Frame_12.png","Frame_13.png","Frame_14.png","Frame_15.png","Frame_16.png","Frame_17.png","Frame_18.png","Frame_19.png","Frame_20.png","Frame_21.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 35,
              day_startY: 115,
              day_sc_array: ["Frame_22.png","Frame_23.png","Frame_24.png","Frame_25.png","Frame_26.png","Frame_27.png","Frame_28.png","Frame_29.png","Frame_30.png","Frame_31.png"],
              day_tc_array: ["Frame_22.png","Frame_23.png","Frame_24.png","Frame_25.png","Frame_26.png","Frame_27.png","Frame_28.png","Frame_29.png","Frame_30.png","Frame_31.png"],
              day_en_array: ["Frame_22.png","Frame_23.png","Frame_24.png","Frame_25.png","Frame_26.png","Frame_27.png","Frame_28.png","Frame_29.png","Frame_30.png","Frame_31.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 35,
              y: 35,
              week_en: ["Frame_3.png","Frame_4.png","Frame_5.png","Frame_6.png","Frame_7.png","Frame_8.png","Frame_9.png"],
              week_tc: ["Frame_3.png","Frame_4.png","Frame_5.png","Frame_6.png","Frame_7.png","Frame_8.png","Frame_9.png"],
              week_sc: ["Frame_3.png","Frame_4.png","Frame_5.png","Frame_6.png","Frame_7.png","Frame_8.png","Frame_9.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 193,
              hour_array: ["Frame_33.png","Frame_34.png","Frame_35.png","Frame_36.png","Frame_37.png","Frame_38.png","Frame_39.png","Frame_40.png","Frame_41.png","Frame_42.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Frame_43.png',
              hour_unit_tc: 'Frame_43.png',
              hour_unit_en: 'Frame_43.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Frame_33.png","Frame_34.png","Frame_35.png","Frame_36.png","Frame_37.png","Frame_38.png","Frame_39.png","Frame_40.png","Frame_41.png","Frame_42.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 296,
              w: 50,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}